-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: assixx
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absences`
--

DROP TABLE IF EXISTS `absences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `absences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `type` enum('vacation','sick','training','other') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text,
  `status` enum('pending','approved','rejected','cancelled') DEFAULT 'pending',
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `absences_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absences_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absences_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences`
--

LOCK TABLES `absences` WRITE;
/*!40000 ALTER TABLE `absences` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `active_shifts_today`
--

DROP TABLE IF EXISTS `active_shifts_today`;
/*!50001 DROP VIEW IF EXISTS `active_shifts_today`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `active_shifts_today` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `user_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `status`,
 1 AS `type`,
 1 AS `template_name`,
 1 AS `department_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `active_surveys`
--

DROP TABLE IF EXISTS `active_surveys`;
/*!50001 DROP VIEW IF EXISTS `active_surveys`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `active_surveys` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `title`,
 1 AS `type`,
 1 AS `status`,
 1 AS `is_anonymous`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `creator_first_name`,
 1 AS `creator_last_name`,
 1 AS `question_count`,
 1 AS `response_count`,
 1 AS `completed_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `admin_logs`
--

DROP TABLE IF EXISTS `admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `admin_id` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_action` (`action`),
  KEY `idx_entity_type` (`entity_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `admin_logs_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_logs_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_logs`
--

LOCK TABLES `admin_logs` WRITE;
/*!40000 ALTER TABLE `admin_logs` DISABLE KEYS */;
INSERT INTO `admin_logs` VALUES (13,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T11:53:21.639Z\\\"}\"',NULL,NULL,'2025-06-08 11:53:21'),(14,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:01.636Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:01'),(15,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:08.171Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:08'),(16,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:32.819Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:32'),(17,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:44.154Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:44'),(18,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T12:04:06.615Z\\\"}\"',NULL,NULL,'2025-06-08 12:04:06'),(19,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T12:04:18.066Z\\\"}\"',NULL,NULL,'2025-06-08 12:04:18'),(20,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T12:04:46.216Z\\\"}\"',NULL,NULL,'2025-06-08 12:04:46'),(21,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T12:05:15.711Z\\\"}\"',NULL,NULL,'2025-06-08 12:05:15'),(22,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T12:05:34.038Z\\\"}\"',NULL,NULL,'2025-06-08 12:05:34'),(23,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T12:05:43.620Z\\\"}\"',NULL,NULL,'2025-06-08 12:05:43'),(24,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:58:54.720Z\\\"}\"',NULL,NULL,'2025-06-08 13:58:54'),(25,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:12.105Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:12'),(26,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:25.973Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:25'),(27,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:25.975Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:25'),(28,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:42.715Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:42'),(29,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:46.512Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:46'),(30,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:46.513Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:46'),(31,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:49.984Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:49'),(32,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:52.841Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:52'),(33,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:52.844Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:52'),(34,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:17.996Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:17'),(35,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:20.329Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:20'),(36,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:20.330Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:20'),(37,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:23.052Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:23'),(38,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:38.952Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:38'),(39,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:38.953Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:38'),(40,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T14:12:50.604Z\\\"}\"',NULL,NULL,'2025-06-08 14:12:50'),(41,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:12:59.190Z\\\"}\"',NULL,NULL,'2025-06-08 14:12:59'),(42,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T16:39:15.345Z\\\"}\"',NULL,NULL,'2025-06-08 16:39:15'),(43,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T16:39:18.218Z\\\"}\"',NULL,NULL,'2025-06-08 16:39:18'),(44,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-09T12:38:29.555Z\\\"}\"',NULL,NULL,'2025-06-09 12:38:29'),(45,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-09T12:38:34.780Z\\\"}\"',NULL,NULL,'2025-06-09 12:38:34'),(46,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-09T21:13:20.965Z\\\"}\"',NULL,NULL,'2025-06-09 21:13:20'),(47,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-09T21:13:36.976Z\\\"}\"',NULL,NULL,'2025-06-09 21:13:36'),(48,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-10T19:10:30.189Z\\\"}\"',NULL,NULL,'2025-06-10 19:10:30'),(49,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-10T19:10:36.281Z\\\"}\"',NULL,NULL,'2025-06-10 19:10:36'),(50,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-10T22:36:51.201Z\\\"}\"',NULL,NULL,'2025-06-10 22:36:51'),(51,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-10T22:36:56.610Z\\\"}\"',NULL,NULL,'2025-06-10 22:36:56'),(52,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:29:49.178Z\\\"}\"',NULL,NULL,'2025-06-12 17:29:49'),(53,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:34:42.991Z\\\"}\"',NULL,NULL,'2025-06-12 17:34:42'),(54,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:34:48.776Z\\\"}\"',NULL,NULL,'2025-06-12 17:34:48'),(55,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:35:25.968Z\\\"}\"',NULL,NULL,'2025-06-12 17:35:25'),(56,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:35:27.965Z\\\"}\"',NULL,NULL,'2025-06-12 17:35:27'),(57,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:08.893Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:08'),(58,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:23.218Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:23'),(59,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:30.114Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:30'),(60,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:35.062Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:35'),(61,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:37.259Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:37');
/*!40000 ALTER TABLE `admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_logs`
--

DROP TABLE IF EXISTS `api_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `method` varchar(10) NOT NULL,
  `endpoint` varchar(255) NOT NULL,
  `status_code` int DEFAULT NULL,
  `request_body` text,
  `response_time_ms` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_status_code` (`status_code`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `api_logs_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `api_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_logs`
--

LOCK TABLES `api_logs` WRITE;
/*!40000 ALTER TABLE `api_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_attachments`
--

DROP TABLE IF EXISTS `blackboard_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_id` int NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_size` int NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `uploaded_by` int NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_entry_id` (`entry_id`),
  KEY `idx_uploaded_by` (`uploaded_by`),
  KEY `idx_mime_type` (`mime_type`),
  CONSTRAINT `blackboard_attachments_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `blackboard_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Stores file attachments for blackboard entries (PDFs, images)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_attachments`
--

LOCK TABLES `blackboard_attachments` WRITE;
/*!40000 ALTER TABLE `blackboard_attachments` DISABLE KEYS */;
INSERT INTO `blackboard_attachments` VALUES (1,4,'1749149640113-835809953.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749149640113-835809953.png',11,'2025-06-05 18:54:00'),(3,6,'1749152715523-524634717.pdf','_ BestÃ¤tigung - aktiv.pdf',81910,'application/pdf','uploads/blackboard/8/1749152715523-524634717.pdf',11,'2025-06-05 19:45:15'),(4,7,'1749154105268-602832762.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749154105268-602832762.png',11,'2025-06-05 20:08:25'),(10,13,'1749468442700-608432106.pdf','_ BestÃ¤tigung - aktiv.pdf',81910,'application/pdf','uploads/blackboard/8/1749468442700-608432106.pdf',11,'2025-06-09 11:27:22'),(12,15,'1749470930281-300484880.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749470930281-300484880.png',11,'2025-06-09 12:08:50'),(13,16,'1749471047931-163369993.png','Screenshot 2025-01-31 114253.png',1072656,'image/png','uploads/blackboard/8/1749471047931-163369993.png',11,'2025-06-09 12:10:48'),(14,17,'1749632060672-154088959.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632060672-154088959.png',11,'2025-06-11 08:54:20'),(15,18,'1749632077296-710991414.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632077296-710991414.png',11,'2025-06-11 08:54:37'),(16,19,'1749632090422-121115274.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632090422-121115274.png',11,'2025-06-11 08:54:50'),(17,20,'1749632100797-886260664.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632100797-886260664.png',11,'2025-06-11 08:55:00'),(18,21,'1749632155299-84010828.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632155299-84010828.png',11,'2025-06-11 08:55:55');
/*!40000 ALTER TABLE `blackboard_attachments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_attachment_count_on_insert` AFTER INSERT ON `blackboard_attachments` FOR EACH ROW BEGIN
    UPDATE blackboard_entries 
    SET attachment_count = (
        SELECT COUNT(*) FROM blackboard_attachments 
        WHERE entry_id = NEW.entry_id
    )
    WHERE id = NEW.entry_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_attachment_count_on_delete` AFTER DELETE ON `blackboard_attachments` FOR EACH ROW BEGIN
    UPDATE blackboard_entries 
    SET attachment_count = (
        SELECT COUNT(*) FROM blackboard_attachments 
        WHERE entry_id = OLD.entry_id
    )
    WHERE id = OLD.entry_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `blackboard_confirmations`
--

DROP TABLE IF EXISTS `blackboard_confirmations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_confirmations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_id` int NOT NULL,
  `user_id` int NOT NULL,
  `confirmed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_confirmation` (`entry_id`,`user_id`),
  KEY `idx_entry_id` (`entry_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `blackboard_confirmations_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `blackboard_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_confirmations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_confirmations`
--

LOCK TABLES `blackboard_confirmations` WRITE;
/*!40000 ALTER TABLE `blackboard_confirmations` DISABLE KEYS */;
/*!40000 ALTER TABLE `blackboard_confirmations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_entries`
--

DROP TABLE IF EXISTS `blackboard_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `org_level` enum('company','department','team') DEFAULT 'company',
  `org_id` int DEFAULT NULL,
  `author_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `color` varchar(20) DEFAULT 'blue',
  `category` varchar(50) DEFAULT NULL,
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `is_pinned` tinyint(1) DEFAULT '0',
  `views` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `status` enum('active','archived') DEFAULT 'active',
  `requires_confirmation` tinyint(1) DEFAULT '0',
  `attachment_count` int DEFAULT '0',
  `attachment_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_author_id` (`author_id`),
  KEY `idx_priority` (`priority`),
  KEY `idx_valid_dates` (`valid_from`,`valid_until`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_is_pinned` (`is_pinned`),
  KEY `idx_org_level` (`org_level`),
  KEY `idx_org_id` (`org_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `blackboard_entries_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_entries_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_entries`
--

LOCK TABLES `blackboard_entries` WRITE;
/*!40000 ALTER TABLE `blackboard_entries` DISABLE KEYS */;
INSERT INTO `blackboard_entries` VALUES (2,8,'company',NULL,11,'sdasd','sad','medium','orange',NULL,NULL,NULL,NULL,0,0,1,'active',0,0,NULL,'2025-06-05 18:52:00','2025-06-05 18:52:00'),(3,8,'company',NULL,11,'testhier','beschireungggggggggggggggggggggggggf','medium','green',NULL,NULL,NULL,NULL,0,0,1,'active',0,0,NULL,'2025-06-05 18:53:22','2025-06-05 18:53:22'),(4,8,'company',NULL,11,'we','qewqe','medium','blue',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-05 18:54:00','2025-06-05 18:54:00'),(6,8,'company',NULL,11,'dsdasd','sdas','medium','pink',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-05 19:45:15','2025-06-05 19:45:15'),(7,8,'company',NULL,11,'ss','sad','medium','yellow',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-05 20:08:25','2025-06-05 20:08:25'),(13,8,'company',NULL,11,'_ Bestätigung - aktiv','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-09 11:27:22','2025-06-09 11:27:22'),(15,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-09 12:08:50','2025-06-09 12:08:50'),(16,8,'company',NULL,11,'Screenshot 2025-01-31 114253','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-09 12:10:47','2025-06-09 12:10:48'),(17,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:54:20','2025-06-11 08:54:20'),(18,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:54:37','2025-06-11 08:54:37'),(19,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:54:50','2025-06-11 08:54:50'),(20,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:55:00','2025-06-11 08:55:00'),(21,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:55:55','2025-06-11 08:55:55');
/*!40000 ALTER TABLE `blackboard_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_entry_tags`
--

DROP TABLE IF EXISTS `blackboard_entry_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_entry_tags` (
  `entry_id` int NOT NULL,
  `tag_id` int NOT NULL,
  PRIMARY KEY (`entry_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `blackboard_entry_tags_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `blackboard_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_entry_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `blackboard_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_entry_tags`
--

LOCK TABLES `blackboard_entry_tags` WRITE;
/*!40000 ALTER TABLE `blackboard_entry_tags` DISABLE KEYS */;
INSERT INTO `blackboard_entry_tags` VALUES (13,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(13,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(13,3),(15,3),(16,3),(17,3),(18,3),(19,3),(20,3),(21,3),(13,4),(15,4),(16,4),(17,4),(18,4),(19,4),(20,4),(21,4),(13,5),(15,5),(16,5),(17,5),(18,5),(19,5),(20,5),(21,5),(13,6),(15,6),(16,6),(17,6),(18,6),(19,6),(20,6),(21,6),(13,7),(15,7),(16,7),(17,7),(18,7),(19,7),(20,7),(21,7),(13,8),(15,8),(16,8),(17,8),(18,8),(19,8),(20,8),(21,8),(13,9),(15,9),(16,9),(17,9),(18,9),(19,9),(20,9),(21,9),(13,10),(15,10),(16,10),(17,10),(18,10),(19,10),(20,10),(21,10);
/*!40000 ALTER TABLE `blackboard_entry_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_tags`
--

DROP TABLE IF EXISTS `blackboard_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `color` varchar(7) DEFAULT '#0066cc',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tag_per_tenant` (`tenant_id`,`name`),
  KEY `idx_tenant_id` (`tenant_id`),
  CONSTRAINT `blackboard_tags_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_tags`
--

LOCK TABLES `blackboard_tags` WRITE;
/*!40000 ALTER TABLE `blackboard_tags` DISABLE KEYS */;
INSERT INTO `blackboard_tags` VALUES (1,8,'a','blue','2025-06-09 11:07:54'),(2,8,'t','blue','2025-06-09 11:07:54'),(3,8,'c','blue','2025-06-09 11:07:54'),(4,8,'h','blue','2025-06-09 11:07:54'),(5,8,'m','blue','2025-06-09 11:07:54'),(6,8,'e','blue','2025-06-09 11:07:54'),(7,8,'n','blue','2025-06-09 11:07:54'),(8,8,',','blue','2025-06-09 11:07:54'),(9,8,'i','blue','2025-06-09 11:07:54'),(10,8,'g','blue','2025-06-09 11:07:54');
/*!40000 ALTER TABLE `blackboard_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_attendees`
--

DROP TABLE IF EXISTS `calendar_attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_attendees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `response_status` enum('pending','accepted','declined','tentative') DEFAULT 'pending',
  `responded_at` timestamp NULL DEFAULT NULL,
  `notification_sent` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_id` (`event_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `calendar_attendees_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_attendees_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_attendees`
--

LOCK TABLES `calendar_attendees` WRITE;
/*!40000 ALTER TABLE `calendar_attendees` DISABLE KEYS */;
INSERT INTO `calendar_attendees` VALUES (6,6,11,'accepted','2025-06-10 18:45:38',0);
/*!40000 ALTER TABLE `calendar_attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_categories`
--

DROP TABLE IF EXISTS `calendar_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `color` varchar(7) DEFAULT '#3498db',
  `icon` varchar(50) DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_category_per_tenant` (`tenant_id`,`name`),
  KEY `idx_tenant_id` (`tenant_id`),
  CONSTRAINT `calendar_categories_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_categories`
--

LOCK TABLES `calendar_categories` WRITE;
/*!40000 ALTER TABLE `calendar_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_events`
--

DROP TABLE IF EXISTS `calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `location` varchar(255) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `all_day` tinyint(1) DEFAULT '0',
  `type` enum('meeting','training','vacation','sick_leave','other') DEFAULT 'other',
  `status` enum('tentative','confirmed','cancelled') DEFAULT 'confirmed',
  `is_private` tinyint(1) DEFAULT '0',
  `reminder_minutes` int DEFAULT NULL,
  `color` varchar(7) DEFAULT '#3498db',
  `recurrence_rule` varchar(500) DEFAULT NULL,
  `parent_event_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_event_id` (`parent_event_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_start_date` (`start_date`),
  KEY `idx_end_date` (`end_date`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `calendar_events_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_events_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_events_ibfk_3` FOREIGN KEY (`parent_event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_events`
--

LOCK TABLES `calendar_events` WRITE;
/*!40000 ALTER TABLE `calendar_events` DISABLE KEYS */;
INSERT INTO `calendar_events` VALUES (6,8,11,'Testtitel','Testbeschr','Stadtlohnort','2025-06-10 19:00:00','2025-06-10 19:00:00',0,'meeting','confirmed',0,NULL,'#9b59b6',NULL,NULL,'2025-06-10 18:45:38','2025-06-10 18:45:38');
/*!40000 ALTER TABLE `calendar_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_participants`
--

DROP TABLE IF EXISTS `calendar_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `response_status` enum('pending','accepted','declined','tentative') DEFAULT 'pending',
  `is_organizer` tinyint(1) DEFAULT '0',
  `is_required` tinyint(1) DEFAULT '1',
  `responded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_participant` (`event_id`,`user_id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_response_status` (`response_status`),
  CONSTRAINT `calendar_participants_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_participants`
--

LOCK TABLES `calendar_participants` WRITE;
/*!40000 ALTER TABLE `calendar_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_recurring_rules`
--

DROP TABLE IF EXISTS `calendar_recurring_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_recurring_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `frequency` enum('daily','weekly','monthly','yearly') NOT NULL,
  `interval_value` int DEFAULT '1',
  `weekdays` varchar(20) DEFAULT NULL,
  `month_day` int DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `count` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `calendar_recurring_rules_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_recurring_rules`
--

LOCK TABLES `calendar_recurring_rules` WRITE;
/*!40000 ALTER TABLE `calendar_recurring_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_recurring_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_reminders`
--

DROP TABLE IF EXISTS `calendar_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_reminders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `minutes_before` int NOT NULL,
  `type` enum('email','notification','both') DEFAULT 'notification',
  `is_sent` tinyint(1) DEFAULT '0',
  `sent_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_sent` (`is_sent`),
  CONSTRAINT `calendar_reminders_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_reminders_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_reminders_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_reminders`
--

LOCK TABLES `calendar_reminders` WRITE;
/*!40000 ALTER TABLE `calendar_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_shares`
--

DROP TABLE IF EXISTS `calendar_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_shares` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `calendar_owner_id` int NOT NULL,
  `shared_with_id` int NOT NULL,
  `permission_level` enum('view','edit') DEFAULT 'view',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_share` (`calendar_owner_id`,`shared_with_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_calendar_owner_id` (`calendar_owner_id`),
  KEY `idx_shared_with_id` (`shared_with_id`),
  CONSTRAINT `calendar_shares_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_shares_ibfk_2` FOREIGN KEY (`calendar_owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_shares_ibfk_3` FOREIGN KEY (`shared_with_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_shares`
--

LOCK TABLES `calendar_shares` WRITE;
/*!40000 ALTER TABLE `calendar_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `chat_activity`
--

DROP TABLE IF EXISTS `chat_activity`;
