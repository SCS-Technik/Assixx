-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: main
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absences`
--

DROP TABLE IF EXISTS `absences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `absences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `type` enum('vacation','sick','training','other') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text,
  `status` enum('pending','approved','rejected','cancelled') DEFAULT 'pending',
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `absences_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absences_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absences_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences`
--

LOCK TABLES `absences` WRITE;
/*!40000 ALTER TABLE `absences` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `active_shifts_today`
--

DROP TABLE IF EXISTS `active_shifts_today`;
/*!50001 DROP VIEW IF EXISTS `active_shifts_today`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `active_shifts_today` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `user_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `status`,
 1 AS `type`,
 1 AS `template_name`,
 1 AS `department_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `active_surveys`
--

DROP TABLE IF EXISTS `active_surveys`;
/*!50001 DROP VIEW IF EXISTS `active_surveys`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `active_surveys` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `title`,
 1 AS `type`,
 1 AS `status`,
 1 AS `is_anonymous`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `creator_first_name`,
 1 AS `creator_last_name`,
 1 AS `question_count`,
 1 AS `response_count`,
 1 AS `completed_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `admin_logs`
--

DROP TABLE IF EXISTS `admin_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `admin_id` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_action` (`action`),
  KEY `idx_entity_type` (`entity_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `admin_logs_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admin_logs_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_logs`
--

LOCK TABLES `admin_logs` WRITE;
/*!40000 ALTER TABLE `admin_logs` DISABLE KEYS */;
INSERT INTO `admin_logs` VALUES (13,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T11:53:21.639Z\\\"}\"',NULL,NULL,'2025-06-08 11:53:21'),(14,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:01.636Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:01'),(15,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:08.171Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:08'),(16,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:32.819Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:32'),(17,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T11:54:44.154Z\\\"}\"',NULL,NULL,'2025-06-08 11:54:44'),(18,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T12:04:06.615Z\\\"}\"',NULL,NULL,'2025-06-08 12:04:06'),(19,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T12:04:18.066Z\\\"}\"',NULL,NULL,'2025-06-08 12:04:18'),(20,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T12:04:46.216Z\\\"}\"',NULL,NULL,'2025-06-08 12:04:46'),(21,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T12:05:15.711Z\\\"}\"',NULL,NULL,'2025-06-08 12:05:15'),(22,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T12:05:34.038Z\\\"}\"',NULL,NULL,'2025-06-08 12:05:34'),(23,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T12:05:43.620Z\\\"}\"',NULL,NULL,'2025-06-08 12:05:43'),(24,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:58:54.720Z\\\"}\"',NULL,NULL,'2025-06-08 13:58:54'),(25,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:12.105Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:12'),(26,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:25.973Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:25'),(27,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:25.975Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:25'),(28,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:42.715Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:42'),(29,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:46.512Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:46'),(30,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:46.513Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:46'),(31,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:49.984Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:49'),(32,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:52.841Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:52'),(33,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T13:59:52.844Z\\\"}\"',NULL,NULL,'2025-06-08 13:59:52'),(34,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:17.996Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:17'),(35,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:20.329Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:20'),(36,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:20.330Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:20'),(37,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:23.052Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:23'),(38,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:38.952Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:38'),(39,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:00:38.953Z\\\"}\"',NULL,NULL,'2025-06-08 14:00:38'),(40,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T14:12:50.604Z\\\"}\"',NULL,NULL,'2025-06-08 14:12:50'),(41,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T14:12:59.190Z\\\"}\"',NULL,NULL,'2025-06-08 14:12:59'),(42,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-08T16:39:15.345Z\\\"}\"',NULL,NULL,'2025-06-08 16:39:15'),(43,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-08T16:39:18.218Z\\\"}\"',NULL,NULL,'2025-06-08 16:39:18'),(44,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-09T12:38:29.555Z\\\"}\"',NULL,NULL,'2025-06-09 12:38:29'),(45,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-09T12:38:34.780Z\\\"}\"',NULL,NULL,'2025-06-09 12:38:34'),(46,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-09T21:13:20.965Z\\\"}\"',NULL,NULL,'2025-06-09 21:13:20'),(47,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-09T21:13:36.976Z\\\"}\"',NULL,NULL,'2025-06-09 21:13:36'),(48,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-10T19:10:30.189Z\\\"}\"',NULL,NULL,'2025-06-10 19:10:30'),(49,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-10T19:10:36.281Z\\\"}\"',NULL,NULL,'2025-06-10 19:10:36'),(50,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-10T22:36:51.201Z\\\"}\"',NULL,NULL,'2025-06-10 22:36:51'),(51,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-10T22:36:56.610Z\\\"}\"',NULL,NULL,'2025-06-10 22:36:56'),(52,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:29:49.178Z\\\"}\"',NULL,NULL,'2025-06-12 17:29:49'),(53,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:34:42.991Z\\\"}\"',NULL,NULL,'2025-06-12 17:34:42'),(54,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:34:48.776Z\\\"}\"',NULL,NULL,'2025-06-12 17:34:48'),(55,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:35:25.968Z\\\"}\"',NULL,NULL,'2025-06-12 17:35:25'),(56,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:35:27.965Z\\\"}\"',NULL,NULL,'2025-06-12 17:35:27'),(57,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:08.893Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:08'),(58,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:23.218Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:23'),(59,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:30.114Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:30'),(60,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:35.062Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:35'),(61,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-12T17:43:37.259Z\\\"}\"',NULL,NULL,'2025-06-12 17:43:37'),(62,8,11,'role_switch_to_employee','user',11,NULL,'\"{\\\"from_role\\\":\\\"admin\\\",\\\"to_role\\\":\\\"employee\\\",\\\"timestamp\\\":\\\"2025-06-16T21:36:38.634Z\\\"}\"',NULL,NULL,'2025-06-16 21:36:38'),(63,8,11,'role_switch_to_admin','user',11,NULL,'\"{\\\"from_role\\\":\\\"employee\\\",\\\"to_role\\\":\\\"admin\\\",\\\"timestamp\\\":\\\"2025-06-16T21:37:50.615Z\\\"}\"',NULL,NULL,'2025-06-16 21:37:50');
/*!40000 ALTER TABLE `admin_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_logs`
--

DROP TABLE IF EXISTS `api_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `method` varchar(10) NOT NULL,
  `endpoint` varchar(255) NOT NULL,
  `status_code` int DEFAULT NULL,
  `request_body` text,
  `response_time_ms` int DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_status_code` (`status_code`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `api_logs_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE SET NULL,
  CONSTRAINT `api_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_logs`
--

LOCK TABLES `api_logs` WRITE;
/*!40000 ALTER TABLE `api_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_attachments`
--

DROP TABLE IF EXISTS `blackboard_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_id` int NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_size` int NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `uploaded_by` int NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_entry_id` (`entry_id`),
  KEY `idx_uploaded_by` (`uploaded_by`),
  KEY `idx_mime_type` (`mime_type`),
  CONSTRAINT `blackboard_attachments_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `blackboard_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Stores file attachments for blackboard entries (PDFs, images)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_attachments`
--

LOCK TABLES `blackboard_attachments` WRITE;
/*!40000 ALTER TABLE `blackboard_attachments` DISABLE KEYS */;
INSERT INTO `blackboard_attachments` VALUES (1,4,'1749149640113-835809953.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749149640113-835809953.png',11,'2025-06-05 18:54:00'),(3,6,'1749152715523-524634717.pdf','_ BestÃ¤tigung - aktiv.pdf',81910,'application/pdf','uploads/blackboard/8/1749152715523-524634717.pdf',11,'2025-06-05 19:45:15'),(4,7,'1749154105268-602832762.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749154105268-602832762.png',11,'2025-06-05 20:08:25'),(10,13,'1749468442700-608432106.pdf','_ BestÃ¤tigung - aktiv.pdf',81910,'application/pdf','uploads/blackboard/8/1749468442700-608432106.pdf',11,'2025-06-09 11:27:22'),(12,15,'1749470930281-300484880.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749470930281-300484880.png',11,'2025-06-09 12:08:50'),(13,16,'1749471047931-163369993.png','Screenshot 2025-01-31 114253.png',1072656,'image/png','uploads/blackboard/8/1749471047931-163369993.png',11,'2025-06-09 12:10:48'),(14,17,'1749632060672-154088959.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632060672-154088959.png',11,'2025-06-11 08:54:20'),(15,18,'1749632077296-710991414.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632077296-710991414.png',11,'2025-06-11 08:54:37'),(16,19,'1749632090422-121115274.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632090422-121115274.png',11,'2025-06-11 08:54:50'),(17,20,'1749632100797-886260664.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632100797-886260664.png',11,'2025-06-11 08:55:00'),(18,21,'1749632155299-84010828.png','ASSIX-05.png',75815,'image/png','uploads/blackboard/8/1749632155299-84010828.png',11,'2025-06-11 08:55:55');
/*!40000 ALTER TABLE `blackboard_attachments` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_attachment_count_on_insert` AFTER INSERT ON `blackboard_attachments` FOR EACH ROW BEGIN
    UPDATE blackboard_entries 
    SET attachment_count = (
        SELECT COUNT(*) FROM blackboard_attachments 
        WHERE entry_id = NEW.entry_id
    )
    WHERE id = NEW.entry_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `update_attachment_count_on_delete` AFTER DELETE ON `blackboard_attachments` FOR EACH ROW BEGIN
    UPDATE blackboard_entries 
    SET attachment_count = (
        SELECT COUNT(*) FROM blackboard_attachments 
        WHERE entry_id = OLD.entry_id
    )
    WHERE id = OLD.entry_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `blackboard_confirmations`
--

DROP TABLE IF EXISTS `blackboard_confirmations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_confirmations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entry_id` int NOT NULL,
  `user_id` int NOT NULL,
  `confirmed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_confirmation` (`entry_id`,`user_id`),
  KEY `idx_entry_id` (`entry_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `blackboard_confirmations_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `blackboard_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_confirmations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_confirmations`
--

LOCK TABLES `blackboard_confirmations` WRITE;
/*!40000 ALTER TABLE `blackboard_confirmations` DISABLE KEYS */;
/*!40000 ALTER TABLE `blackboard_confirmations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_entries`
--

DROP TABLE IF EXISTS `blackboard_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `org_level` enum('company','department','team') DEFAULT 'company',
  `org_id` int DEFAULT NULL,
  `author_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `color` varchar(20) DEFAULT 'blue',
  `category` varchar(50) DEFAULT NULL,
  `valid_from` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `is_pinned` tinyint(1) DEFAULT '0',
  `views` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `status` enum('active','archived') DEFAULT 'active',
  `requires_confirmation` tinyint(1) DEFAULT '0',
  `attachment_count` int DEFAULT '0',
  `attachment_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_author_id` (`author_id`),
  KEY `idx_priority` (`priority`),
  KEY `idx_valid_dates` (`valid_from`,`valid_until`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_is_pinned` (`is_pinned`),
  KEY `idx_org_level` (`org_level`),
  KEY `idx_org_id` (`org_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `blackboard_entries_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_entries_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_entries`
--

LOCK TABLES `blackboard_entries` WRITE;
/*!40000 ALTER TABLE `blackboard_entries` DISABLE KEYS */;
INSERT INTO `blackboard_entries` VALUES (2,8,'company',NULL,11,'sdasd','sad','medium','orange',NULL,NULL,NULL,NULL,0,0,1,'active',0,0,NULL,'2025-06-05 18:52:00','2025-06-05 18:52:00'),(3,8,'company',NULL,11,'testhier','beschireungggggggggggggggggggggggggf','medium','green',NULL,NULL,NULL,NULL,0,0,1,'active',0,0,NULL,'2025-06-05 18:53:22','2025-06-05 18:53:22'),(4,8,'company',NULL,11,'we','qewqe','medium','blue',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-05 18:54:00','2025-06-05 18:54:00'),(6,8,'company',NULL,11,'dsdasd','sdas','medium','pink',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-05 19:45:15','2025-06-05 19:45:15'),(7,8,'company',NULL,11,'ss','sad','medium','yellow',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-05 20:08:25','2025-06-05 20:08:25'),(13,8,'company',NULL,11,'_ Bestätigung - aktiv','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-09 11:27:22','2025-06-09 11:27:22'),(15,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-09 12:08:50','2025-06-09 12:08:50'),(16,8,'company',NULL,11,'Screenshot 2025-01-31 114253','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-09 12:10:47','2025-06-09 12:10:48'),(17,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:54:20','2025-06-11 08:54:20'),(18,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:54:37','2025-06-11 08:54:37'),(19,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:54:50','2025-06-11 08:54:50'),(20,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:55:00','2025-06-11 08:55:00'),(21,8,'company',NULL,11,'ASSIX-05','[Attachment:large]','','white',NULL,NULL,NULL,NULL,0,0,1,'active',0,1,NULL,'2025-06-11 08:55:55','2025-06-11 08:55:55');
/*!40000 ALTER TABLE `blackboard_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_entry_tags`
--

DROP TABLE IF EXISTS `blackboard_entry_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_entry_tags` (
  `entry_id` int NOT NULL,
  `tag_id` int NOT NULL,
  PRIMARY KEY (`entry_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `blackboard_entry_tags_ibfk_1` FOREIGN KEY (`entry_id`) REFERENCES `blackboard_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blackboard_entry_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `blackboard_tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_entry_tags`
--

LOCK TABLES `blackboard_entry_tags` WRITE;
/*!40000 ALTER TABLE `blackboard_entry_tags` DISABLE KEYS */;
INSERT INTO `blackboard_entry_tags` VALUES (13,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(13,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(13,3),(15,3),(16,3),(17,3),(18,3),(19,3),(20,3),(21,3),(13,4),(15,4),(16,4),(17,4),(18,4),(19,4),(20,4),(21,4),(13,5),(15,5),(16,5),(17,5),(18,5),(19,5),(20,5),(21,5),(13,6),(15,6),(16,6),(17,6),(18,6),(19,6),(20,6),(21,6),(13,7),(15,7),(16,7),(17,7),(18,7),(19,7),(20,7),(21,7),(13,8),(15,8),(16,8),(17,8),(18,8),(19,8),(20,8),(21,8),(13,9),(15,9),(16,9),(17,9),(18,9),(19,9),(20,9),(21,9),(13,10),(15,10),(16,10),(17,10),(18,10),(19,10),(20,10),(21,10);
/*!40000 ALTER TABLE `blackboard_entry_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blackboard_tags`
--

DROP TABLE IF EXISTS `blackboard_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blackboard_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `color` varchar(7) DEFAULT '#0066cc',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tag_per_tenant` (`tenant_id`,`name`),
  KEY `idx_tenant_id` (`tenant_id`),
  CONSTRAINT `blackboard_tags_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blackboard_tags`
--

LOCK TABLES `blackboard_tags` WRITE;
/*!40000 ALTER TABLE `blackboard_tags` DISABLE KEYS */;
INSERT INTO `blackboard_tags` VALUES (1,8,'a','blue','2025-06-09 11:07:54'),(2,8,'t','blue','2025-06-09 11:07:54'),(3,8,'c','blue','2025-06-09 11:07:54'),(4,8,'h','blue','2025-06-09 11:07:54'),(5,8,'m','blue','2025-06-09 11:07:54'),(6,8,'e','blue','2025-06-09 11:07:54'),(7,8,'n','blue','2025-06-09 11:07:54'),(8,8,',','blue','2025-06-09 11:07:54'),(9,8,'i','blue','2025-06-09 11:07:54'),(10,8,'g','blue','2025-06-09 11:07:54');
/*!40000 ALTER TABLE `blackboard_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_attendees`
--

DROP TABLE IF EXISTS `calendar_attendees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_attendees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `response_status` enum('pending','accepted','declined','tentative') DEFAULT 'pending',
  `responded_at` timestamp NULL DEFAULT NULL,
  `notification_sent` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_id` (`event_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `calendar_attendees_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_attendees_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_attendees`
--

LOCK TABLES `calendar_attendees` WRITE;
/*!40000 ALTER TABLE `calendar_attendees` DISABLE KEYS */;
INSERT INTO `calendar_attendees` VALUES (6,6,11,'accepted','2025-06-10 18:45:38',0);
/*!40000 ALTER TABLE `calendar_attendees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_categories`
--

DROP TABLE IF EXISTS `calendar_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `color` varchar(7) DEFAULT '#3498db',
  `icon` varchar(50) DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_category_per_tenant` (`tenant_id`,`name`),
  KEY `idx_tenant_id` (`tenant_id`),
  CONSTRAINT `calendar_categories_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_categories`
--

LOCK TABLES `calendar_categories` WRITE;
/*!40000 ALTER TABLE `calendar_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_events`
--

DROP TABLE IF EXISTS `calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `location` varchar(255) DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `all_day` tinyint(1) DEFAULT '0',
  `type` enum('meeting','training','vacation','sick_leave','other') DEFAULT 'other',
  `status` enum('tentative','confirmed','cancelled') DEFAULT 'confirmed',
  `is_private` tinyint(1) DEFAULT '0',
  `reminder_minutes` int DEFAULT NULL,
  `color` varchar(7) DEFAULT '#3498db',
  `recurrence_rule` varchar(500) DEFAULT NULL,
  `parent_event_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_event_id` (`parent_event_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_start_date` (`start_date`),
  KEY `idx_end_date` (`end_date`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `calendar_events_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_events_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_events_ibfk_3` FOREIGN KEY (`parent_event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_events`
--

LOCK TABLES `calendar_events` WRITE;
/*!40000 ALTER TABLE `calendar_events` DISABLE KEYS */;
INSERT INTO `calendar_events` VALUES (6,8,11,'Testtitel','Testbeschr','Stadtlohnort','2025-06-10 19:00:00','2025-06-10 19:00:00',0,'meeting','confirmed',0,NULL,'#9b59b6',NULL,NULL,'2025-06-10 18:45:38','2025-06-10 18:45:38');
/*!40000 ALTER TABLE `calendar_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_participants`
--

DROP TABLE IF EXISTS `calendar_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `response_status` enum('pending','accepted','declined','tentative') DEFAULT 'pending',
  `is_organizer` tinyint(1) DEFAULT '0',
  `is_required` tinyint(1) DEFAULT '1',
  `responded_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_participant` (`event_id`,`user_id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_response_status` (`response_status`),
  CONSTRAINT `calendar_participants_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_participants`
--

LOCK TABLES `calendar_participants` WRITE;
/*!40000 ALTER TABLE `calendar_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_recurring_rules`
--

DROP TABLE IF EXISTS `calendar_recurring_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_recurring_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event_id` int NOT NULL,
  `frequency` enum('daily','weekly','monthly','yearly') NOT NULL,
  `interval_value` int DEFAULT '1',
  `weekdays` varchar(20) DEFAULT NULL,
  `month_day` int DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `count` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  CONSTRAINT `calendar_recurring_rules_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_recurring_rules`
--

LOCK TABLES `calendar_recurring_rules` WRITE;
/*!40000 ALTER TABLE `calendar_recurring_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_recurring_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_reminders`
--

DROP TABLE IF EXISTS `calendar_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_reminders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `event_id` int NOT NULL,
  `user_id` int NOT NULL,
  `minutes_before` int NOT NULL,
  `type` enum('email','notification','both') DEFAULT 'notification',
  `is_sent` tinyint(1) DEFAULT '0',
  `sent_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_sent` (`is_sent`),
  CONSTRAINT `calendar_reminders_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_reminders_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `calendar_events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_reminders_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_reminders`
--

LOCK TABLES `calendar_reminders` WRITE;
/*!40000 ALTER TABLE `calendar_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar_shares`
--

DROP TABLE IF EXISTS `calendar_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_shares` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `calendar_owner_id` int NOT NULL,
  `shared_with_id` int NOT NULL,
  `permission_level` enum('view','edit') DEFAULT 'view',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_share` (`calendar_owner_id`,`shared_with_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_calendar_owner_id` (`calendar_owner_id`),
  KEY `idx_shared_with_id` (`shared_with_id`),
  CONSTRAINT `calendar_shares_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_shares_ibfk_2` FOREIGN KEY (`calendar_owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calendar_shares_ibfk_3` FOREIGN KEY (`shared_with_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_shares`
--

LOCK TABLES `calendar_shares` WRITE;
/*!40000 ALTER TABLE `calendar_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_notifications`
--

DROP TABLE IF EXISTS `chat_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `message_id` int NOT NULL,
  `type` enum('message','mention','group_invite') DEFAULT 'message',
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_message_id` (`message_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `chat_notifications_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_notifications_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_notifications_ibfk_3` FOREIGN KEY (`message_id`) REFERENCES `messages_old_backup` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_notifications`
--

LOCK TABLES `chat_notifications` WRITE;
/*!40000 ALTER TABLE `chat_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversation_participants`
--

DROP TABLE IF EXISTS `conversation_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversation_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversation_id` int NOT NULL,
  `user_id` int NOT NULL,
  `joined_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_participant` (`conversation_id`,`user_id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `conversation_participants_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `conversation_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversation_participants`
--

LOCK TABLES `conversation_participants` WRITE;
/*!40000 ALTER TABLE `conversation_participants` DISABLE KEYS */;
INSERT INTO `conversation_participants` VALUES (29,15,11,'2025-06-14 13:12:51',0),(30,15,20,'2025-06-14 13:12:51',0);
/*!40000 ALTER TABLE `conversation_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversations`
--

DROP TABLE IF EXISTS `conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_group` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant` (`tenant_id`),
  CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversations`
--

LOCK TABLES `conversations` WRITE;
/*!40000 ALTER TABLE `conversations` DISABLE KEYS */;
INSERT INTO `conversations` VALUES (15,8,NULL,0,'2025-06-14 13:12:51','2025-06-14 13:12:51');
/*!40000 ALTER TABLE `conversations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `current_employee_availability`
--

DROP TABLE IF EXISTS `current_employee_availability`;
/*!50001 DROP VIEW IF EXISTS `current_employee_availability`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `current_employee_availability` AS SELECT 
 1 AS `employee_id`,
 1 AS `tenant_id`,
 1 AS `username`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `current_status`,
 1 AS `current_reason`,
 1 AS `available_from`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `manager_id` int DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `visibility` enum('public','private') DEFAULT 'public',
  `notes` text,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_dept_name_per_tenant` (`tenant_id`,`name`),
  KEY `created_by` (`created_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_manager_id` (`manager_id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_status` (`status`),
  KEY `idx_visibility` (`visibility`),
  CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `departments_ibfk_2` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `departments_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `departments_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,8,'IT','Beschreinung test',NULL,NULL,'active','public',NULL,NULL,'2025-06-04 14:05:48','2025-06-04 20:10:15');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_read_status`
--

DROP TABLE IF EXISTS `document_read_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_read_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_id` int NOT NULL,
  `user_id` int NOT NULL,
  `tenant_id` int NOT NULL,
  `read_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_document_user_read` (`document_id`,`user_id`,`tenant_id`),
  KEY `tenant_id` (`tenant_id`),
  KEY `idx_user_read_status` (`user_id`,`tenant_id`),
  KEY `idx_document_read_status` (`document_id`,`tenant_id`),
  CONSTRAINT `document_read_status_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_read_status_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `document_read_status_ibfk_3` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_read_status`
--

LOCK TABLES `document_read_status` WRITE;
/*!40000 ALTER TABLE `document_read_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_read_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `document_summary`
--

DROP TABLE IF EXISTS `document_summary`;
/*!50001 DROP VIEW IF EXISTS `document_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `document_summary` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `user_id`,
 1 AS `category`,
 1 AS `filename`,
 1 AS `file_size`,
 1 AS `uploaded_at`,
 1 AS `is_archived`,
 1 AS `owner_first_name`,
 1 AS `owner_last_name`,
 1 AS `owner_email`,
 1 AS `uploader_first_name`,
 1 AS `uploader_last_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `recipient_type` enum('user','team','department','company') DEFAULT 'user',
  `team_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `category` enum('personal','work','training','general','salary') NOT NULL,
  `filename` varchar(255) NOT NULL,
  `original_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int NOT NULL,
  `file_content` longblob,
  `mime_type` varchar(100) DEFAULT NULL,
  `description` text,
  `year` int DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT '0',
  `is_archived` tinyint(1) DEFAULT '0',
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `archived_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category` (`category`),
  KEY `idx_uploaded_at` (`uploaded_at`),
  KEY `idx_is_archived` (`is_archived`),
  KEY `idx_documents_recipient_type` (`recipient_type`),
  KEY `idx_documents_team_id` (`team_id`),
  KEY `idx_documents_department_id` (`department_id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_documents_department_id` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_documents_team_id` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT NULL,
  `template_key` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body_html` text NOT NULL,
  `body_text` text,
  `variables` json DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_template` (`tenant_id`,`template_key`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_template_key` (`template_key`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `email_templates_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_availability`
--

DROP TABLE IF EXISTS `employee_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_availability` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `tenant_id` int NOT NULL,
  `status` enum('available','unavailable','vacation','sick','training','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'available',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_availability_created_by` (`created_by`),
  KEY `idx_availability_employee` (`employee_id`),
  KEY `idx_availability_tenant` (`tenant_id`),
  KEY `idx_availability_dates` (`start_date`,`end_date`),
  KEY `idx_availability_status` (`status`),
  CONSTRAINT `fk_availability_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_availability_employee` FOREIGN KEY (`employee_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_availability_tenant` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_availability_dates` CHECK ((`end_date` >= `start_date`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_availability`
--

LOCK TABLES `employee_availability` WRITE;
/*!40000 ALTER TABLE `employee_availability` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_availability_old`
--

DROP TABLE IF EXISTS `employee_availability_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_availability_old` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `date` date NOT NULL,
  `availability_type` enum('available','preferred','unavailable','sick','vacation') DEFAULT 'available',
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`date`),
  KEY `idx_user_availability` (`user_id`,`availability_type`),
  CONSTRAINT `employee_availability_old_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_availability_old`
--

LOCK TABLES `employee_availability_old` WRITE;
/*!40000 ALTER TABLE `employee_availability_old` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_availability_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `employee_overview`
--

DROP TABLE IF EXISTS `employee_overview`;
/*!50001 DROP VIEW IF EXISTS `employee_overview`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `employee_overview` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `email`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `phone`,
 1 AS `role`,
 1 AS `status`,
 1 AS `created_at`,
 1 AS `last_login`,
 1 AS `department_name`,
 1 AS `team_name`,
 1 AS `document_count`,
 1 AS `message_count`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `employees_without_documents`
--

DROP TABLE IF EXISTS `employees_without_documents`;
/*!50001 DROP VIEW IF EXISTS `employees_without_documents`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `employees_without_documents` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `email`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `created_at`,
 1 AS `department_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `feature_usage_logs`
--

DROP TABLE IF EXISTS `feature_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feature_usage_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `feature_id` int NOT NULL,
  `user_id` int NOT NULL,
  `action` varchar(100) NOT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_feature_id` (`feature_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `feature_usage_logs_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `feature_usage_logs_ibfk_2` FOREIGN KEY (`feature_id`) REFERENCES `features` (`id`) ON DELETE CASCADE,
  CONSTRAINT `feature_usage_logs_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature_usage_logs`
--

LOCK TABLES `feature_usage_logs` WRITE;
/*!40000 ALTER TABLE `feature_usage_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `feature_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `feature_usage_summary`
--

DROP TABLE IF EXISTS `feature_usage_summary`;
/*!50001 DROP VIEW IF EXISTS `feature_usage_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `feature_usage_summary` AS SELECT 
 1 AS `feature_id`,
 1 AS `code`,
 1 AS `name`,
 1 AS `category`,
 1 AS `base_price`,
 1 AS `tenant_count`,
 1 AS `usage_count`,
 1 AS `active_count`,
 1 AS `avg_days_active`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `features` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `category` enum('basic','core','premium','enterprise') DEFAULT 'basic',
  `base_price` decimal(10,2) DEFAULT '0.00',
  `is_active` tinyint(1) DEFAULT '1',
  `requires_setup` tinyint(1) DEFAULT '0',
  `setup_instructions` text,
  `icon` varchar(100) DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`),
  KEY `idx_category` (`category`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features`
--

LOCK TABLES `features` WRITE;
/*!40000 ALTER TABLE `features` DISABLE KEYS */;
INSERT INTO `features` VALUES (1,'basic_employees','Basis Mitarbeiterverwaltung','Verwaltung von bis zu 50 Mitarbeitern','basic',0.00,1,0,NULL,'users',1,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(2,'unlimited_employees','Unbegrenzte Mitarbeiter','Keine Begrenzung der Mitarbeiteranzahl','premium',49.99,1,0,NULL,'users-plus',2,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(3,'document_upload','Dokument Upload','Upload und Verwaltung von Dokumenten','basic',0.00,1,0,NULL,'file-text',3,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(4,'payslip_management','Lohnabrechnungsverwaltung','Digitale Lohnabrechnungen verwalten','basic',0.00,1,0,NULL,'file-invoice-dollar',4,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(5,'email_notifications','E-Mail Benachrichtigungen','Automatische E-Mail Benachrichtigungen','premium',19.99,1,0,NULL,'envelope',5,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(6,'advanced_reports','Erweiterte Berichte','Detaillierte Auswertungen und Statistiken','premium',29.99,1,0,NULL,'chart-bar',6,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(7,'api_access','API Zugang','Vollständiger API-Zugriff für Integrationen','enterprise',99.99,1,0,NULL,'plug',7,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(8,'custom_branding','Custom Branding','Eigenes Logo und Farbschema','enterprise',49.99,1,0,NULL,'palette',8,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(9,'priority_support','Priority Support','24/7 Priority Support mit SLA','enterprise',149.99,1,0,NULL,'headset',9,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(10,'automation','Automatisierung','Workflows und Prozesse automatisieren','enterprise',79.99,1,0,NULL,'robot',10,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(11,'employee_self_service','Mitarbeiter Self-Service','Mitarbeiter können eigene Daten verwalten','premium',24.99,1,0,NULL,'user-edit',11,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(12,'multi_language','Mehrsprachigkeit','Interface in mehreren Sprachen','premium',19.99,1,0,NULL,'language',12,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(13,'audit_trail','Audit Trail','Vollständige Aktivitätsprotokolle','enterprise',39.99,1,0,NULL,'history',13,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(14,'data_export','Daten Export','Export in verschiedene Formate','premium',14.99,1,0,NULL,'download',14,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(15,'team_management','Team Verwaltung','Teams und Abteilungen verwalten','premium',34.99,1,0,NULL,'users-cog',15,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(16,'calendar','Kalender-System','Termine, Events und Erinnerungen verwalten','premium',24.99,1,0,NULL,'calendar',16,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(17,'blackboard','Digitales Schwarzes Brett','Ankündigungen und wichtige Informationen teilen','premium',19.99,1,0,NULL,'clipboard',17,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(18,'shift_planning','Schichtplanungs-System','Erweiterte Schichtplanung mit Teams und Vorlagen','enterprise',49.99,1,0,NULL,'clock',18,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(19,'kvp','Kontinuierlicher Verbesserungsprozess','KVP-Vorschläge sammeln und verwalten','enterprise',39.99,1,0,NULL,'trending-up',19,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(20,'chat','Chat System','Interne Kommunikation mit Gruppen-Chats','premium',19.99,1,0,NULL,'message-circle',20,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(21,'surveys','Umfrage-Tool','Erstellen und Auswerten von Mitarbeiterumfragen','premium',29.99,1,0,NULL,'bar-chart',21,'2025-06-01 21:18:02','2025-06-01 21:18:02');
/*!40000 ALTER TABLE `features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kvp_attachments`
--

DROP TABLE IF EXISTS `kvp_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kvp_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `suggestion_id` int NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(100) NOT NULL,
  `file_size` int NOT NULL,
  `uploaded_by` int NOT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `uploaded_by` (`uploaded_by`),
  KEY `suggestion_id` (`suggestion_id`),
  CONSTRAINT `kvp_attachments_ibfk_1` FOREIGN KEY (`suggestion_id`) REFERENCES `kvp_suggestions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_attachments_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvp_attachments`
--

LOCK TABLES `kvp_attachments` WRITE;
/*!40000 ALTER TABLE `kvp_attachments` DISABLE KEYS */;
INSERT INTO `kvp_attachments` VALUES (1,1,'_ BestÃ¤tigung - aktiv.pdf','/app/backend/uploads/kvp/attachments-1749922724644-727511775.pdf','application/pdf',81910,20,'2025-06-14 17:38:44');
/*!40000 ALTER TABLE `kvp_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kvp_categories`
--

DROP TABLE IF EXISTS `kvp_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kvp_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `color` varchar(20) DEFAULT '#3498db',
  `icon` varchar(50) DEFAULT 'ðŸ’¡',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_id_2` (`tenant_id`,`name`),
  KEY `tenant_id` (`tenant_id`),
  CONSTRAINT `kvp_categories_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvp_categories`
--

LOCK TABLES `kvp_categories` WRITE;
/*!40000 ALTER TABLE `kvp_categories` DISABLE KEYS */;
INSERT INTO `kvp_categories` VALUES (13,8,'Sicherheit','Verbesserungen zur Arbeitssicherheit','#e74c3c','ðŸ›¡ï¸','2025-06-14 17:17:40'),(14,8,'Effizienz','Prozessoptimierungen und Zeitersparnis','#2ecc71','âš¡','2025-06-14 17:17:40'),(15,8,'QualitÃ¤t','QualitÃ¤tsverbesserungen und Fehlervermeidung','#3498db','â­','2025-06-14 17:17:40'),(16,8,'Umwelt','Umweltfreundliche Verbesserungen','#27ae60','ðŸŒ±','2025-06-14 17:17:40'),(17,8,'Ergonomie','Arbeitsplatzverbesserungen','#9b59b6','ðŸ‘¤','2025-06-14 17:17:40'),(18,8,'Kosteneinsparung','MaÃŸnahmen zur Kostenreduzierung','#f39c12','ðŸ’°','2025-06-14 17:17:40');
/*!40000 ALTER TABLE `kvp_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kvp_comments`
--

DROP TABLE IF EXISTS `kvp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kvp_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `suggestion_id` int NOT NULL,
  `user_id` int NOT NULL,
  `comment` text NOT NULL,
  `is_internal` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `suggestion_id` (`suggestion_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `kvp_comments_ibfk_1` FOREIGN KEY (`suggestion_id`) REFERENCES `kvp_suggestions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvp_comments`
--

LOCK TABLES `kvp_comments` WRITE;
/*!40000 ALTER TABLE `kvp_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `kvp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kvp_points`
--

DROP TABLE IF EXISTS `kvp_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kvp_points` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `suggestion_id` int NOT NULL,
  `points` int NOT NULL,
  `reason` enum('submission','implementation','rating','bonus') NOT NULL,
  `awarded_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `awarded_by` (`awarded_by`),
  KEY `tenant_id` (`tenant_id`),
  KEY `user_id` (`user_id`),
  KEY `suggestion_id` (`suggestion_id`),
  CONSTRAINT `kvp_points_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_points_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_points_ibfk_3` FOREIGN KEY (`suggestion_id`) REFERENCES `kvp_suggestions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_points_ibfk_4` FOREIGN KEY (`awarded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvp_points`
--

LOCK TABLES `kvp_points` WRITE;
/*!40000 ALTER TABLE `kvp_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `kvp_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kvp_ratings`
--

DROP TABLE IF EXISTS `kvp_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kvp_ratings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `suggestion_id` int NOT NULL,
  `user_id` int NOT NULL,
  `rating` int NOT NULL,
  `comment` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suggestion_id` (`suggestion_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `suggestion_id_2` (`suggestion_id`),
  CONSTRAINT `kvp_ratings_ibfk_1` FOREIGN KEY (`suggestion_id`) REFERENCES `kvp_suggestions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_ratings_chk_1` CHECK (((`rating` >= 1) and (`rating` <= 5)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvp_ratings`
--

LOCK TABLES `kvp_ratings` WRITE;
/*!40000 ALTER TABLE `kvp_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `kvp_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kvp_status_history`
--

DROP TABLE IF EXISTS `kvp_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kvp_status_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `suggestion_id` int NOT NULL,
  `old_status` enum('new','pending','in_review','approved','implemented','rejected','archived') DEFAULT NULL,
  `new_status` enum('new','pending','in_review','approved','implemented','rejected','archived') NOT NULL,
  `changed_by` int NOT NULL,
  `change_reason` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `changed_by` (`changed_by`),
  KEY `suggestion_id` (`suggestion_id`),
  CONSTRAINT `kvp_status_history_ibfk_1` FOREIGN KEY (`suggestion_id`) REFERENCES `kvp_suggestions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_status_history_ibfk_2` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvp_status_history`
--

LOCK TABLES `kvp_status_history` WRITE;
/*!40000 ALTER TABLE `kvp_status_history` DISABLE KEYS */;
INSERT INTO `kvp_status_history` VALUES (1,1,'new','in_review',11,'Status geändert zu In Prüfung','2025-06-14 17:48:22'),(2,1,'in_review','approved',11,'Status geändert zu Genehmigt','2025-06-14 17:48:25'),(3,1,'approved','implemented',11,'Status geändert zu Umgesetzt','2025-06-14 17:48:30'),(4,1,'implemented','rejected',11,'Status geändert zu Abgelehnt','2025-06-14 17:48:31'),(5,1,'rejected','archived',11,'Status geändert zu Archiviert','2025-06-14 17:48:33'),(6,1,'archived','approved',11,'Status geändert zu Genehmigt','2025-06-14 17:48:35');
/*!40000 ALTER TABLE `kvp_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kvp_suggestions`
--

DROP TABLE IF EXISTS `kvp_suggestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kvp_suggestions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category_id` int DEFAULT NULL,
  `org_level` enum('company','department','team') NOT NULL,
  `org_id` int NOT NULL,
  `submitted_by` int NOT NULL,
  `assigned_to` int DEFAULT NULL,
  `status` enum('new','pending','in_review','approved','implemented','rejected','archived') DEFAULT 'new',
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `expected_benefit` text,
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `actual_savings` decimal(10,2) DEFAULT NULL,
  `implementation_date` date DEFAULT NULL,
  `rejection_reason` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `tenant_id` (`tenant_id`),
  KEY `org_level` (`org_level`,`org_id`),
  KEY `status` (`status`),
  KEY `submitted_by` (`submitted_by`),
  KEY `assigned_to` (`assigned_to`),
  CONSTRAINT `kvp_suggestions_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_suggestions_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `kvp_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `kvp_suggestions_ibfk_3` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kvp_suggestions_ibfk_4` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvp_suggestions`
--

LOCK TABLES `kvp_suggestions` WRITE;
/*!40000 ALTER TABLE `kvp_suggestions` DISABLE KEYS */;
INSERT INTO `kvp_suggestions` VALUES (1,8,'titeldd','beschirn',14,'company',8,20,11,'approved','normal','nnoteewd',NULL,NULL,NULL,NULL,'2025-06-14 17:38:44','2025-06-14 17:48:35');
/*!40000 ALTER TABLE `kvp_suggestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_attachments`
--

DROP TABLE IF EXISTS `message_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `message_id` int NOT NULL,
  `filename` varchar(255) NOT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_size` int NOT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_message_id` (`message_id`),
  CONSTRAINT `message_attachments_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_attachments_ibfk_2` FOREIGN KEY (`message_id`) REFERENCES `messages_old_backup` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_attachments`
--

LOCK TABLES `message_attachments` WRITE;
/*!40000 ALTER TABLE `message_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_group_members`
--

DROP TABLE IF EXISTS `message_group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_group_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `group_id` int NOT NULL,
  `user_id` int NOT NULL,
  `role` enum('member','admin') DEFAULT 'member',
  `joined_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_read_at` timestamp NULL DEFAULT NULL,
  `notification_enabled` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_group_member` (`group_id`,`user_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_group_id` (`group_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_role` (`role`),
  CONSTRAINT `message_group_members_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_group_members_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `message_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_group_members_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_group_members`
--

LOCK TABLES `message_group_members` WRITE;
/*!40000 ALTER TABLE `message_group_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_groups`
--

DROP TABLE IF EXISTS `message_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `type` enum('public','private','department','team') DEFAULT 'private',
  `avatar_url` varchar(500) DEFAULT NULL,
  `created_by` int NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_type` (`type`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `message_groups_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_groups_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_groups`
--

LOCK TABLES `message_groups` WRITE;
/*!40000 ALTER TABLE `message_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_read_receipts`
--

DROP TABLE IF EXISTS `message_read_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_read_receipts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `message_id` int NOT NULL,
  `user_id` int NOT NULL,
  `read_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_read_receipt` (`message_id`,`user_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_message_id` (`message_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `message_read_receipts_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_read_receipts_ibfk_2` FOREIGN KEY (`message_id`) REFERENCES `messages_old_backup` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_read_receipts_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_read_receipts`
--

LOCK TABLES `message_read_receipts` WRITE;
/*!40000 ALTER TABLE `message_read_receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_read_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_status`
--

DROP TABLE IF EXISTS `message_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message_id` int NOT NULL,
  `user_id` int NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` timestamp NULL DEFAULT NULL,
  `is_archived` tinyint(1) DEFAULT '0',
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_message_user` (`message_id`,`user_id`),
  KEY `idx_message_id` (`message_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_is_archived` (`is_archived`),
  CONSTRAINT `fk_message_status_message` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `message_status_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_status`
--

LOCK TABLES `message_status` WRITE;
/*!40000 ALTER TABLE `message_status` DISABLE KEYS */;
INSERT INTO `message_status` VALUES (10,25,11,1,'2025-06-14 13:16:34',0,NULL,'2025-06-14 13:16:34','2025-06-14 13:16:34'),(11,26,11,1,'2025-06-14 13:16:34',0,NULL,'2025-06-14 13:16:34','2025-06-14 13:16:34'),(12,32,11,1,'2025-06-14 13:16:34',0,NULL,'2025-06-14 13:16:34','2025-06-14 13:16:34'),(13,24,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(14,27,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(15,28,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(16,29,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(17,30,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(18,31,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(19,33,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(20,34,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(21,35,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(22,36,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(23,37,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(24,38,20,1,'2025-06-14 13:16:43',0,NULL,'2025-06-14 13:16:43','2025-06-14 13:16:43'),(25,39,11,1,'2025-06-14 13:16:57',0,NULL,'2025-06-14 13:16:57','2025-06-14 13:16:57'),(26,40,11,1,'2025-06-14 13:16:57',0,NULL,'2025-06-14 13:16:57','2025-06-14 13:16:57'),(27,41,11,1,'2025-06-14 13:16:57',0,NULL,'2025-06-14 13:16:57','2025-06-14 13:16:57'),(28,42,11,1,'2025-06-14 13:16:57',0,NULL,'2025-06-14 13:16:57','2025-06-14 13:16:57'),(29,43,11,1,'2025-06-14 13:16:57',0,NULL,'2025-06-14 13:16:57','2025-06-14 13:16:57'),(30,44,11,1,'2025-06-14 13:16:57',0,NULL,'2025-06-14 13:16:57','2025-06-14 13:16:57'),(31,45,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(32,46,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(33,47,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(34,48,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(35,49,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(36,50,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(37,51,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(38,52,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(39,53,20,1,'2025-06-14 13:17:11',0,NULL,'2025-06-14 13:17:11','2025-06-14 13:17:11'),(40,54,20,1,'2025-06-16 10:42:26',0,NULL,'2025-06-16 10:42:26','2025-06-16 10:42:26'),(41,55,11,1,'2025-06-16 10:42:33',0,NULL,'2025-06-16 10:42:33','2025-06-16 10:42:33'),(42,56,11,1,'2025-06-16 10:42:33',0,NULL,'2025-06-16 10:42:33','2025-06-16 10:42:33'),(43,57,11,1,'2025-06-16 10:42:33',0,NULL,'2025-06-16 10:42:33','2025-06-16 10:42:33'),(44,58,11,1,'2025-06-16 10:42:33',0,NULL,'2025-06-16 10:42:33','2025-06-16 10:42:33'),(45,59,20,1,'2025-06-16 13:03:54',0,NULL,'2025-06-16 13:03:54','2025-06-16 13:03:54'),(46,60,11,1,'2025-06-16 20:53:29',0,NULL,'2025-06-16 20:53:29','2025-06-16 20:53:29');
/*!40000 ALTER TABLE `message_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `conversation_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachment_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_conversation` (`conversation_id`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_created` (`created_at`),
  KEY `tenant_id` (`tenant_id`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_ibfk_3` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (24,8,15,11,'was geeeet ab',NULL,NULL,NULL,0,'2025-06-14 13:13:02',NULL),(25,8,15,20,'nicht ebi dri bre?',NULL,NULL,NULL,0,'2025-06-14 13:13:23',NULL),(26,8,15,20,'wallah=',NULL,NULL,NULL,0,'2025-06-14 13:13:24',NULL),(27,8,15,11,'sdsds',NULL,NULL,NULL,0,'2025-06-14 13:13:40',NULL),(28,8,15,11,'sd',NULL,NULL,NULL,0,'2025-06-14 13:13:40',NULL),(29,8,15,11,'dsd',NULL,NULL,NULL,0,'2025-06-14 13:13:40',NULL),(30,8,15,11,'sds',NULL,NULL,NULL,0,'2025-06-14 13:13:40',NULL),(31,8,15,11,'sd',NULL,NULL,NULL,0,'2025-06-14 13:13:40',NULL),(32,8,15,20,'ddadsada',NULL,NULL,NULL,0,'2025-06-14 13:13:51',NULL),(33,8,15,11,'coolie',NULL,NULL,NULL,0,'2025-06-14 13:16:37',NULL),(34,8,15,11,'xy',NULL,NULL,NULL,0,'2025-06-14 13:16:38',NULL),(35,8,15,11,'asd',NULL,NULL,NULL,0,'2025-06-14 13:16:39',NULL),(36,8,15,11,'sd',NULL,NULL,NULL,0,'2025-06-14 13:16:39',NULL),(37,8,15,11,'sds',NULL,NULL,NULL,0,'2025-06-14 13:16:39',NULL),(38,8,15,11,'dsd',NULL,NULL,NULL,0,'2025-06-14 13:16:39',NULL),(39,8,15,20,'s',NULL,NULL,NULL,0,'2025-06-14 13:16:45',NULL),(40,8,15,20,'sda',NULL,NULL,NULL,0,'2025-06-14 13:16:45',NULL),(41,8,15,20,'asd',NULL,NULL,NULL,0,'2025-06-14 13:16:45',NULL),(42,8,15,20,'dsads',NULL,NULL,NULL,0,'2025-06-14 13:16:46',NULL),(43,8,15,20,'sd',NULL,NULL,NULL,0,'2025-06-14 13:16:46',NULL),(44,8,15,20,'dsa',NULL,NULL,NULL,0,'2025-06-14 13:16:46',NULL),(45,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:02',NULL),(46,8,15,11,'s',NULL,NULL,NULL,0,'2025-06-14 13:17:03',NULL),(47,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:04',NULL),(48,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:04',NULL),(49,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:05',NULL),(50,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:05',NULL),(51,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:06',NULL),(52,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:06',NULL),(53,8,15,11,'as',NULL,NULL,NULL,0,'2025-06-14 13:17:07',NULL),(54,8,15,11,'sss',NULL,NULL,NULL,0,'2025-06-16 10:42:08',NULL),(55,8,15,20,'sfdssdf',NULL,NULL,NULL,0,'2025-06-16 10:42:28',NULL),(56,8,15,20,'ssdffdsfds',NULL,NULL,NULL,0,'2025-06-16 10:42:28',NULL),(57,8,15,20,'dfs',NULL,NULL,NULL,0,'2025-06-16 10:42:28',NULL),(58,8,15,20,'dsf',NULL,NULL,NULL,0,'2025-06-16 10:42:28',NULL),(59,8,15,11,'hallo',NULL,NULL,NULL,0,'2025-06-16 13:03:50',NULL),(60,8,15,20,'was geht ab',NULL,NULL,NULL,0,'2025-06-16 20:53:24',NULL),(61,8,15,11,'nicht bi ri?',NULL,NULL,NULL,0,'2025-06-16 20:53:33',NULL);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages_old_backup`
--

DROP TABLE IF EXISTS `messages_old_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages_old_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `receiver_id` int DEFAULT NULL,
  `group_id` int DEFAULT NULL,
  `content` text NOT NULL,
  `type` enum('text','file','image','system') DEFAULT 'text',
  `file_url` varchar(500) DEFAULT NULL,
  `is_edited` tinyint(1) DEFAULT '0',
  `edited_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_sender_id` (`sender_id`),
  KEY `idx_receiver_id` (`receiver_id`),
  KEY `idx_group_id` (`group_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_is_deleted` (`is_deleted`),
  CONSTRAINT `messages_old_backup_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_old_backup_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_old_backup_ibfk_3` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_old_backup_ibfk_4` FOREIGN KEY (`group_id`) REFERENCES `message_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `messages_old_backup_chk_1` CHECK ((((`receiver_id` is not null) and (`group_id` is null)) or ((`receiver_id` is null) and (`group_id` is not null))))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages_old_backup`
--

LOCK TABLES `messages_old_backup` WRITE;
/*!40000 ALTER TABLE `messages_old_backup` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages_old_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_preferences`
--

DROP TABLE IF EXISTS `notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `notification_type` varchar(50) NOT NULL,
  `email_enabled` tinyint(1) DEFAULT '1',
  `push_enabled` tinyint(1) DEFAULT '1',
  `in_app_enabled` tinyint(1) DEFAULT '1',
  `frequency` enum('immediate','hourly','daily','weekly') DEFAULT 'immediate',
  `quiet_hours_start` time DEFAULT NULL,
  `quiet_hours_end` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_notification_pref` (`user_id`,`notification_type`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_notification_type` (`notification_type`),
  CONSTRAINT `notification_preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_preferences`
--

LOCK TABLES `notification_preferences` WRITE;
/*!40000 ALTER TABLE `notification_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_history`
--

DROP TABLE IF EXISTS `payment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `subscription_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) DEFAULT 'EUR',
  `status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `invoice_number` varchar(50) DEFAULT NULL,
  `invoice_url` varchar(500) DEFAULT NULL,
  `failure_reason` text,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_subscription_id` (`subscription_id`),
  KEY `idx_status` (`status`),
  KEY `idx_invoice_number` (`invoice_number`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `payment_history_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_history_ibfk_2` FOREIGN KEY (`subscription_id`) REFERENCES `tenant_subscriptions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_history`
--

LOCK TABLES `payment_history` WRITE;
/*!40000 ALTER TABLE `payment_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plan_features`
--

DROP TABLE IF EXISTS `plan_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan_features` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plan_id` int NOT NULL,
  `feature_id` int NOT NULL,
  `is_included` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_plan_feature` (`plan_id`,`feature_id`),
  KEY `idx_plan_id` (`plan_id`),
  KEY `idx_feature_id` (`feature_id`),
  CONSTRAINT `plan_features_ibfk_1` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `plan_features_ibfk_2` FOREIGN KEY (`feature_id`) REFERENCES `features` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan_features`
--

LOCK TABLES `plan_features` WRITE;
/*!40000 ALTER TABLE `plan_features` DISABLE KEYS */;
INSERT INTO `plan_features` VALUES (1,1,1,1,'2025-06-02 19:21:07'),(2,1,3,1,'2025-06-02 19:21:07'),(3,1,5,1,'2025-06-02 19:21:07'),(4,2,6,1,'2025-06-02 19:21:07'),(5,2,1,1,'2025-06-02 19:21:07'),(6,2,17,1,'2025-06-02 19:21:07'),(7,2,16,1,'2025-06-02 19:21:07'),(8,2,20,1,'2025-06-02 19:21:07'),(9,2,3,1,'2025-06-02 19:21:07'),(10,2,5,1,'2025-06-02 19:21:07'),(11,2,15,1,'2025-06-02 19:21:07'),(19,3,1,1,'2025-06-02 19:21:07'),(20,3,2,1,'2025-06-02 19:21:07'),(21,3,3,1,'2025-06-02 19:21:07'),(22,3,4,1,'2025-06-02 19:21:07'),(23,3,5,1,'2025-06-02 19:21:07'),(24,3,6,1,'2025-06-02 19:21:07'),(25,3,7,1,'2025-06-02 19:21:07'),(26,3,8,1,'2025-06-02 19:21:07'),(27,3,9,1,'2025-06-02 19:21:07'),(28,3,10,1,'2025-06-02 19:21:07'),(29,3,11,1,'2025-06-02 19:21:07'),(30,3,12,1,'2025-06-02 19:21:07'),(31,3,13,1,'2025-06-02 19:21:07'),(32,3,14,1,'2025-06-02 19:21:07'),(33,3,15,1,'2025-06-02 19:21:07'),(34,3,16,1,'2025-06-02 19:21:07'),(35,3,17,1,'2025-06-02 19:21:07'),(36,3,18,1,'2025-06-02 19:21:07'),(37,3,19,1,'2025-06-02 19:21:07'),(38,3,20,1,'2025-06-02 19:21:07'),(39,3,21,1,'2025-06-02 19:21:07');
/*!40000 ALTER TABLE `plan_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `base_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `max_employees` int DEFAULT NULL,
  `max_admins` int DEFAULT NULL,
  `max_storage_gb` int DEFAULT '100',
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'basic','Basic','Perfekt fÃ¼r kleine Teams und Startups',49.00,10,1,100,1,1,'2025-06-02 19:21:07','2025-06-02 19:21:07'),(2,'professional','Professional','FÃ¼r wachsende Unternehmen',149.00,50,3,500,1,2,'2025-06-02 19:21:07','2025-06-02 19:21:07'),(3,'enterprise','Enterprise','FÃ¼r groÃŸe Organisationen',299.00,NULL,NULL,1000,1,3,'2025-06-02 19:21:07','2025-06-02 19:21:07');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_messages`
--

DROP TABLE IF EXISTS `scheduled_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `conversation_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_for` timestamp NOT NULL,
  `delivery_type` enum('immediate','break_time','after_work') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'immediate',
  `is_sent` tinyint(1) DEFAULT '0',
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_scheduled` (`scheduled_for`),
  KEY `idx_sent_status` (`is_sent`),
  KEY `tenant_id` (`tenant_id`),
  KEY `conversation_id` (`conversation_id`),
  KEY `sender_id` (`sender_id`),
  CONSTRAINT `scheduled_messages_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scheduled_messages_ibfk_2` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scheduled_messages_ibfk_3` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_messages`
--

LOCK TABLES `scheduled_messages` WRITE;
/*!40000 ALTER TABLE `scheduled_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `scheduled_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_logs`
--

DROP TABLE IF EXISTS `security_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `action` enum('login_success','login_failed','logout','password_reset','account_locked','suspicious_activity') NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `details` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `security_logs_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `security_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_logs`
--

LOCK TABLES `security_logs` WRITE;
/*!40000 ALTER TABLE `security_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_assignments`
--

DROP TABLE IF EXISTS `shift_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `shift_id` int NOT NULL,
  `user_id` int NOT NULL,
  `assignment_type` enum('assigned','requested','available','unavailable') DEFAULT 'assigned',
  `status` enum('pending','accepted','declined','cancelled') DEFAULT 'pending',
  `assigned_by` int DEFAULT NULL,
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `response_at` timestamp NULL DEFAULT NULL,
  `notes` text,
  `overtime_hours` decimal(4,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_shift_user` (`shift_id`,`user_id`),
  KEY `idx_user_status` (`user_id`,`status`),
  KEY `idx_shift_type` (`shift_id`,`assignment_type`),
  KEY `idx_assigned_by` (`assigned_by`),
  CONSTRAINT `shift_assignments_ibfk_1` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_assignments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_assignments_ibfk_3` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_assignments`
--

LOCK TABLES `shift_assignments` WRITE;
/*!40000 ALTER TABLE `shift_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_exchange_requests`
--

DROP TABLE IF EXISTS `shift_exchange_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_exchange_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `shift_id` int NOT NULL,
  `requester_id` int NOT NULL,
  `target_user_id` int DEFAULT NULL,
  `exchange_type` enum('give_away','swap','request_coverage') DEFAULT 'give_away',
  `target_shift_id` int DEFAULT NULL,
  `message` text,
  `status` enum('pending','accepted','declined','cancelled','completed') DEFAULT 'pending',
  `response_message` text,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_requester` (`requester_id`),
  KEY `idx_target_user` (`target_user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shift` (`shift_id`),
  KEY `idx_target_shift` (`target_shift_id`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `shift_exchange_requests_ibfk_1` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_exchange_requests_ibfk_2` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_exchange_requests_ibfk_3` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_exchange_requests_ibfk_4` FOREIGN KEY (`target_shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_exchange_requests_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_exchange_requests`
--

LOCK TABLES `shift_exchange_requests` WRITE;
/*!40000 ALTER TABLE `shift_exchange_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_exchange_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_group_members`
--

DROP TABLE IF EXISTS `shift_group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_group_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `user_id` int NOT NULL,
  `role` enum('member','lead','substitute') DEFAULT 'member',
  `joined_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_group_member` (`group_id`,`user_id`),
  KEY `idx_group_id` (`group_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_role` (`role`),
  CONSTRAINT `shift_group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `shift_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_group_members`
--

LOCK TABLES `shift_group_members` WRITE;
/*!40000 ALTER TABLE `shift_group_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_groups`
--

DROP TABLE IF EXISTS `shift_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `manager_id` int DEFAULT NULL,
  `color` varchar(7) DEFAULT '#3498db',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_manager_id` (`manager_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `shift_groups_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_groups_ibfk_2` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_groups`
--

LOCK TABLES `shift_groups` WRITE;
/*!40000 ALTER TABLE `shift_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_notes`
--

DROP TABLE IF EXISTS `shift_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `shift_id` int NOT NULL,
  `user_id` int NOT NULL,
  `note` text NOT NULL,
  `type` enum('info','warning','important') DEFAULT 'info',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_shift_id` (`shift_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_type` (`type`),
  CONSTRAINT `shift_notes_ibfk_1` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_notes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_notes`
--

LOCK TABLES `shift_notes` WRITE;
/*!40000 ALTER TABLE `shift_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_pattern_assignments`
--

DROP TABLE IF EXISTS `shift_pattern_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_pattern_assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pattern_id` int NOT NULL,
  `user_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_pattern_id` (`pattern_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `shift_pattern_assignments_ibfk_1` FOREIGN KEY (`pattern_id`) REFERENCES `shift_patterns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_pattern_assignments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_pattern_assignments`
--

LOCK TABLES `shift_pattern_assignments` WRITE;
/*!40000 ALTER TABLE `shift_pattern_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_pattern_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_patterns`
--

DROP TABLE IF EXISTS `shift_patterns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_patterns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `pattern_data` json NOT NULL,
  `cycle_days` int NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `shift_patterns_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_patterns`
--

LOCK TABLES `shift_patterns` WRITE;
/*!40000 ALTER TABLE `shift_patterns` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_patterns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_plans`
--

DROP TABLE IF EXISTS `shift_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text,
  `department_id` int DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('draft','published','locked','archived') DEFAULT 'draft',
  `created_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_dates` (`tenant_id`,`start_date`,`end_date`),
  KEY `idx_department` (`department_id`),
  KEY `idx_team` (`team_id`),
  KEY `idx_status` (`status`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `shift_plans_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_plans_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shift_plans_ibfk_3` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shift_plans_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_plans_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_plans`
--

LOCK TABLES `shift_plans` WRITE;
/*!40000 ALTER TABLE `shift_plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_swaps`
--

DROP TABLE IF EXISTS `shift_swaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_swaps` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requester_id` int NOT NULL,
  `shift_id` int NOT NULL,
  `target_user_id` int DEFAULT NULL,
  `target_shift_id` int DEFAULT NULL,
  `reason` text,
  `status` enum('pending','accepted','rejected','cancelled') DEFAULT 'pending',
  `responded_at` timestamp NULL DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `target_shift_id` (`target_shift_id`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_requester_id` (`requester_id`),
  KEY `idx_shift_id` (`shift_id`),
  KEY `idx_target_user_id` (`target_user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `shift_swaps_ibfk_1` FOREIGN KEY (`requester_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_swaps_ibfk_2` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_swaps_ibfk_3` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_swaps_ibfk_4` FOREIGN KEY (`target_shift_id`) REFERENCES `shifts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shift_swaps_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_swaps`
--

LOCK TABLES `shift_swaps` WRITE;
/*!40000 ALTER TABLE `shift_swaps` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_swaps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_templates`
--

DROP TABLE IF EXISTS `shift_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shift_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `break_minutes` int DEFAULT '0',
  `color` varchar(7) DEFAULT '#3498db',
  `is_night_shift` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `shift_templates_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_templates`
--

LOCK TABLES `shift_templates` WRITE;
/*!40000 ALTER TABLE `shift_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shifts`
--

DROP TABLE IF EXISTS `shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shifts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `plan_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `template_id` int DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `required_employees` int DEFAULT '1',
  `actual_start` datetime DEFAULT NULL,
  `actual_end` datetime DEFAULT NULL,
  `break_minutes` int DEFAULT '0',
  `status` enum('planned','confirmed','in_progress','completed','cancelled') DEFAULT 'planned',
  `type` enum('regular','overtime','standby','vacation','sick','holiday') DEFAULT 'regular',
  `notes` text,
  `department_id` int NOT NULL,
  `team_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_shift` (`user_id`,`date`,`start_time`),
  KEY `template_id` (`template_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_date` (`date`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `plan_id` (`plan_id`),
  KEY `team_id` (`team_id`),
  KEY `shifts_ibfk_6` (`department_id`),
  CONSTRAINT `shifts_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shifts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shifts_ibfk_3` FOREIGN KEY (`template_id`) REFERENCES `shift_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shifts_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shifts_ibfk_5` FOREIGN KEY (`plan_id`) REFERENCES `shift_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `shifts_ibfk_6` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `shifts_ibfk_7` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shifts`
--

LOCK TABLES `shifts` WRITE;
/*!40000 ALTER TABLE `shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `shifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_plans`
--

DROP TABLE IF EXISTS `subscription_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text,
  `price_monthly` decimal(10,2) NOT NULL,
  `price_yearly` decimal(10,2) DEFAULT NULL,
  `max_users` int DEFAULT NULL,
  `max_storage_gb` int DEFAULT NULL,
  `features` json DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_code` (`code`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_plans`
--

LOCK TABLES `subscription_plans` WRITE;
/*!40000 ALTER TABLE `subscription_plans` DISABLE KEYS */;
INSERT INTO `subscription_plans` VALUES (1,'Free','','Für große Organisationen',199.99,1999.99,NULL,500,'[\"unlimited_employees\", \"document_upload\", \"payslip_management\", \"email_notifications\", \"advanced_reports\", \"api_access\", \"custom_branding\", \"priority_support\", \"automation\", \"employee_self_service\", \"multi_language\", \"audit_trail\", \"data_export\", \"team_management\", \"calendar\", \"blackboard\", \"shift_planning\", \"kvp\", \"chat\", \"surveys\"]',1,'2025-06-01 21:18:01','2025-06-01 21:18:01');
/*!40000 ALTER TABLE `subscription_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_answers`
--

DROP TABLE IF EXISTS `survey_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_answers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `response_id` int NOT NULL,
  `question_id` int NOT NULL,
  `answer_text` text,
  `answer_options` json DEFAULT NULL,
  `answer_number` decimal(10,2) DEFAULT NULL,
  `answer_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_response_id` (`response_id`),
  KEY `idx_question_id` (`question_id`),
  CONSTRAINT `survey_answers_ibfk_1` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `survey_questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_answers`
--

LOCK TABLES `survey_answers` WRITE;
/*!40000 ALTER TABLE `survey_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_comments`
--

DROP TABLE IF EXISTS `survey_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `user_id` int NOT NULL,
  `comment` text NOT NULL,
  `is_public` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_survey_id` (`survey_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `survey_comments_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_comments`
--

LOCK TABLES `survey_comments` WRITE;
/*!40000 ALTER TABLE `survey_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_participants`
--

DROP TABLE IF EXISTS `survey_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `user_id` int NOT NULL,
  `invited_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reminder_sent_at` timestamp NULL DEFAULT NULL,
  `completed` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_participant` (`survey_id`,`user_id`),
  KEY `idx_survey_id` (`survey_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_completed` (`completed`),
  CONSTRAINT `survey_participants_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_participants_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_participants`
--

LOCK TABLES `survey_participants` WRITE;
/*!40000 ALTER TABLE `survey_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_questions`
--

DROP TABLE IF EXISTS `survey_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `question_text` text NOT NULL,
  `question_type` enum('single_choice','multiple_choice','text','rating','scale','yes_no','date','number') NOT NULL,
  `is_required` tinyint(1) DEFAULT '1',
  `options` json DEFAULT NULL,
  `validation_rules` json DEFAULT NULL,
  `order_index` int DEFAULT '0',
  `help_text` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_survey_id` (`survey_id`),
  KEY `idx_order_index` (`order_index`),
  CONSTRAINT `survey_questions_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_questions`
--

LOCK TABLES `survey_questions` WRITE;
/*!40000 ALTER TABLE `survey_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_reminders`
--

DROP TABLE IF EXISTS `survey_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_reminders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `reminder_date` datetime NOT NULL,
  `message` text,
  `is_sent` tinyint(1) DEFAULT '0',
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_survey_id` (`survey_id`),
  KEY `idx_reminder_date` (`reminder_date`),
  KEY `idx_is_sent` (`is_sent`),
  CONSTRAINT `survey_reminders_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_reminders`
--

LOCK TABLES `survey_reminders` WRITE;
/*!40000 ALTER TABLE `survey_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_responses`
--

DROP TABLE IF EXISTS `survey_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_responses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survey_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `status` enum('in_progress','completed','abandoned') DEFAULT 'in_progress',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  PRIMARY KEY (`id`),
  KEY `idx_survey_id` (`survey_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_status` (`status`),
  KEY `idx_completed_at` (`completed_at`),
  CONSTRAINT `survey_responses_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_responses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_responses`
--

LOCK TABLES `survey_responses` WRITE;
/*!40000 ALTER TABLE `survey_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_templates`
--

DROP TABLE IF EXISTS `survey_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `category` varchar(50) DEFAULT NULL,
  `template_data` json NOT NULL,
  `is_public` tinyint(1) DEFAULT '0',
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_category` (`category`),
  KEY `idx_is_public` (`is_public`),
  CONSTRAINT `survey_templates_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `survey_templates_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey_templates`
--

LOCK TABLES `survey_templates` WRITE;
/*!40000 ALTER TABLE `survey_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `surveys`
--

DROP TABLE IF EXISTS `surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `surveys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `type` enum('feedback','satisfaction','poll','assessment','other') DEFAULT 'feedback',
  `status` enum('draft','active','paused','completed','archived') DEFAULT 'draft',
  `is_anonymous` tinyint(1) DEFAULT '0',
  `allow_multiple_responses` tinyint(1) DEFAULT '0',
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_by` int NOT NULL,
  `target_departments` json DEFAULT NULL,
  `target_teams` json DEFAULT NULL,
  `notification_sent` tinyint(1) DEFAULT '0',
  `reminder_sent` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`type`),
  KEY `idx_dates` (`start_date`,`end_date`),
  KEY `idx_created_by` (`created_by`),
  CONSTRAINT `surveys_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `surveys_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `surveys`
--

LOCK TABLES `surveys` WRITE;
/*!40000 ALTER TABLE `surveys` DISABLE KEYS */;
/*!40000 ALTER TABLE `surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `level` enum('debug','info','warning','error','critical') NOT NULL,
  `category` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `context` json DEFAULT NULL,
  `stack_trace` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_level` (`level`),
  KEY `idx_category` (`category`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `value_type` enum('string','number','boolean','json') DEFAULT 'string',
  `category` varchar(50) DEFAULT NULL,
  `description` text,
  `is_public` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_category` (`category`),
  KEY `idx_is_public` (`is_public`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'app_name','Assixx','string','general','Name der Anwendung',1,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(2,'default_language','de','string','localization','Standard-Sprache',1,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(3,'max_upload_size','10485760','number','limits','Maximale Upload-Größe in Bytes (10MB)',0,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(4,'session_timeout','7200','number','security','Session-Timeout in Sekunden (2 Stunden)',0,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(5,'password_min_length','8','number','security','Minimale Passwortlänge',1,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(6,'trial_days','30','number','billing','Anzahl der Testtage',1,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(7,'maintenance_mode','false','boolean','system','Wartungsmodus aktiviert',0,'2025-06-01 21:18:02','2025-06-01 21:18:02'),(8,'allow_registration','true','boolean','system','Registrierung erlaubt',1,'2025-06-01 21:18:02','2025-06-01 21:18:02');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `department_id` int DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `team_lead_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_team_name_per_dept` (`department_id`,`name`),
  KEY `created_by` (`created_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_department_id` (`department_id`),
  KEY `idx_team_lead_id` (`team_lead_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `teams_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teams_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `teams_ibfk_3` FOREIGN KEY (`team_lead_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `teams_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_addons`
--

DROP TABLE IF EXISTS `tenant_addons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_addons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `addon_type` enum('employees','admins','storage_gb') NOT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) GENERATED ALWAYS AS ((`quantity` * `unit_price`)) STORED,
  `status` enum('active','cancelled') DEFAULT 'active',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tenant_addon` (`tenant_id`,`addon_type`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_addon_type` (`addon_type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `tenant_addons_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_addons`
--

LOCK TABLES `tenant_addons` WRITE;
/*!40000 ALTER TABLE `tenant_addons` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_addons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_admins`
--

DROP TABLE IF EXISTS `tenant_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `is_primary` tinyint(1) DEFAULT '0',
  `assigned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `assigned_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_admin` (`tenant_id`,`user_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `fk_tenant_admins_assigned_by` (`assigned_by`),
  CONSTRAINT `fk_tenant_admins_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tenant_admins_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tenant_admins_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_admins`
--

LOCK TABLES `tenant_admins` WRITE;
/*!40000 ALTER TABLE `tenant_admins` DISABLE KEYS */;
INSERT INTO `tenant_admins` VALUES (6,8,10,1,'2025-06-03 16:59:31',NULL);
/*!40000 ALTER TABLE `tenant_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_features`
--

DROP TABLE IF EXISTS `tenant_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_features` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `feature_id` int NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `activated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `activated_by` int DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `custom_config` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tenant_feature` (`tenant_id`,`feature_id`),
  KEY `activated_by` (`activated_by`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_feature_id` (`feature_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `tenant_features_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tenant_features_ibfk_2` FOREIGN KEY (`feature_id`) REFERENCES `features` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tenant_features_ibfk_3` FOREIGN KEY (`activated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_features`
--

LOCK TABLES `tenant_features` WRITE;
/*!40000 ALTER TABLE `tenant_features` DISABLE KEYS */;
INSERT INTO `tenant_features` VALUES (112,8,1,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(113,8,3,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(114,8,4,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(115,8,2,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(116,8,5,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(117,8,6,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(118,8,11,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(119,8,12,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(120,8,14,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(121,8,15,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(122,8,16,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(123,8,17,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(124,8,20,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(125,8,21,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(126,8,7,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(127,8,8,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(128,8,9,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(129,8,10,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(130,8,13,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(131,8,18,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31'),(132,8,19,1,'2025-06-03 16:59:31',NULL,'2025-06-17 16:59:31',NULL,'2025-06-03 16:59:31','2025-06-03 16:59:31');
/*!40000 ALTER TABLE `tenant_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_plans`
--

DROP TABLE IF EXISTS `tenant_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `plan_id` int NOT NULL,
  `status` enum('active','trial','cancelled','expired') DEFAULT 'active',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `custom_price` decimal(10,2) DEFAULT NULL,
  `billing_cycle` enum('monthly','yearly') DEFAULT 'monthly',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `plan_id` (`plan_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `tenant_plans_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tenant_plans_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_plans`
--

LOCK TABLES `tenant_plans` WRITE;
/*!40000 ALTER TABLE `tenant_plans` DISABLE KEYS */;
INSERT INTO `tenant_plans` VALUES (18,8,1,'cancelled','2025-06-03 16:59:31',NULL,'2025-06-03 17:00:07',NULL,'monthly','2025-06-03 16:59:31','2025-06-03 17:00:07'),(19,8,3,'active','2025-06-03 17:00:07',NULL,NULL,NULL,'monthly','2025-06-03 17:00:07','2025-06-03 17:00:07');
/*!40000 ALTER TABLE `tenant_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_settings`
--

DROP TABLE IF EXISTS `tenant_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `value_type` enum('string','number','boolean','json') DEFAULT 'string',
  `category` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_tenant_setting` (`tenant_id`,`setting_key`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_category` (`category`),
  CONSTRAINT `tenant_settings_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_settings`
--

LOCK TABLES `tenant_settings` WRITE;
/*!40000 ALTER TABLE `tenant_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `tenant_statistics`
--

DROP TABLE IF EXISTS `tenant_statistics`;
/*!50001 DROP VIEW IF EXISTS `tenant_statistics`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `tenant_statistics` AS SELECT 
 1 AS `tenant_id`,
 1 AS `tenant_name`,
 1 AS `subdomain`,
 1 AS `status`,
 1 AS `plan_type`,
 1 AS `total_users`,
 1 AS `admin_count`,
 1 AS `employee_count`,
 1 AS `department_count`,
 1 AS `team_count`,
 1 AS `active_features`,
 1 AS `created_at`,
 1 AS `subscription_end_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `tenant_subscriptions`
--

DROP TABLE IF EXISTS `tenant_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `plan_id` int DEFAULT NULL,
  `status` enum('active','cancelled','expired','suspended') DEFAULT 'active',
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `stripe_subscription_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `tenant_subscriptions_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_subscriptions`
--

LOCK TABLES `tenant_subscriptions` WRITE;
/*!40000 ALTER TABLE `tenant_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL,
  `subdomain` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text,
  `status` enum('trial','active','suspended','cancelled') DEFAULT 'trial',
  `trial_ends_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `settings` json DEFAULT NULL,
  `stripe_customer_id` varchar(255) DEFAULT NULL,
  `stripe_subscription_id` varchar(255) DEFAULT NULL,
  `current_plan` enum('basic','premium','enterprise') DEFAULT 'basic',
  `billing_email` varchar(255) DEFAULT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `primary_color` varchar(7) DEFAULT '#0066cc',
  `created_by` int DEFAULT NULL,
  `current_plan_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subdomain` (`subdomain`),
  KEY `idx_subdomain` (`subdomain`),
  KEY `idx_status` (`status`),
  KEY `idx_trial_ends` (`trial_ends_at`),
  KEY `fk_tenants_created_by` (`created_by`),
  KEY `idx_current_plan` (`current_plan_id`),
  CONSTRAINT `fk_tenants_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tenants_ibfk_1` FOREIGN KEY (`current_plan_id`) REFERENCES `plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES (8,'scs','scs','simon@hotmail.de','+49 123456789',NULL,'trial','2025-06-17 16:59:31','2025-06-03 16:59:31','2025-06-03 17:00:07',NULL,NULL,NULL,'basic','simon@hotmail.de',NULL,'#0066cc',NULL,3);
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_quotas`
--

DROP TABLE IF EXISTS `usage_quotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_quotas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `resource_type` enum('users','storage','api_calls','documents','messages') NOT NULL,
  `used_amount` int DEFAULT '0',
  `limit_amount` int DEFAULT NULL,
  `reset_period` enum('daily','weekly','monthly','yearly') DEFAULT 'monthly',
  `last_reset` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_quota` (`tenant_id`,`resource_type`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_resource_type` (`resource_type`),
  CONSTRAINT `usage_quotas_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_quotas`
--

LOCK TABLES `usage_quotas` WRITE;
/*!40000 ALTER TABLE `usage_quotas` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_quotas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_chat_status`
--

DROP TABLE IF EXISTS `user_chat_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_chat_status` (
  `user_id` int NOT NULL,
  `tenant_id` int NOT NULL,
  `is_online` tinyint(1) DEFAULT '0',
  `last_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_typing` tinyint(1) DEFAULT '0',
  `typing_in_conversation` int DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_is_online` (`is_online`),
  KEY `idx_last_seen` (`last_seen`),
  CONSTRAINT `user_chat_status_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_chat_status_ibfk_2` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_chat_status`
--

LOCK TABLES `user_chat_status` WRITE;
/*!40000 ALTER TABLE `user_chat_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_chat_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `value_type` enum('string','number','boolean','json') DEFAULT 'string',
  `category` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_setting` (`user_id`,`setting_key`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category` (`category`),
  CONSTRAINT `user_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_settings`
--

LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_teams`
--

DROP TABLE IF EXISTS `user_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `team_id` int NOT NULL,
  `joined_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `role` enum('member','lead') DEFAULT 'member',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_team` (`user_id`,`team_id`),
  KEY `idx_tenant_id` (`tenant_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_team_id` (`team_id`),
  CONSTRAINT `user_teams_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_teams_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_teams_ibfk_3` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_teams`
--

LOCK TABLES `user_teams` WRITE;
/*!40000 ALTER TABLE `user_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT '1',
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `profile_picture_url` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('root','admin','employee') NOT NULL DEFAULT 'employee',
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `age` int DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `iban` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `notes` text,
  `department_id` int DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `address` text,
  `birthday` date DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `emergency_contact` text,
  `editable_fields` json DEFAULT NULL,
  `notification_preferences` json DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `is_archived` tinyint(1) DEFAULT '0',
  `status` enum('active','inactive') DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `password_reset_expires` timestamp NULL DEFAULT NULL,
  `two_factor_secret` varchar(255) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `availability_status` enum('available','unavailable','vacation','sick') DEFAULT 'available',
  `availability_start` date DEFAULT NULL,
  `availability_end` date DEFAULT NULL,
  `availability_notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_tenant_users` (`tenant_id`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_archived` (`is_archived`),
  KEY `fk_users_department` (`department_id`),
  KEY `idx_users_availability_status` (`availability_status`),
  CONSTRAINT `fk_users_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (10,8,'simon@hotmail.de','simon@hotmail.de',NULL,'$2b$10$sf1WjtYwM8/C/JazL1NigedUD5GTq2Q6oVRa4WZxW80RS6ib8vYVS','root','Simon','Testroot',NULL,'SCSRT10120620251555',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/uploads/profile-pictures/profile-1748981567291-351407821.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,'active',NULL,NULL,NULL,NULL,0,'2025-06-03 16:59:31','2025-06-12 15:55:13',NULL,NULL,'available',NULL,NULL,NULL),(11,8,'admin','admin@scs.de',NULL,'$2b$10$if9MpjQWB3elBW835yHm/.ZcQfXJ9Nf3KQpzlVZwYBZe/KqyHEZ/G','admin','Son','Goku',NULL,'SCSAD11120620251555','',NULL,'',1,'bereichsleiter',NULL,NULL,'/uploads/profile-pictures/profile-1749219601491-984018280.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,'active',NULL,NULL,NULL,NULL,0,'2025-06-03 17:00:37','2025-06-12 15:55:13',NULL,NULL,'available',NULL,NULL,NULL),(20,8,'employee','employee@scs.de',NULL,'$2b$10$VCag16pyK4C5i5AqJQS7wOwMTcKSc200xa6MhERr/.kSKAq.Rp6Ye','employee','Sono','Gohanemp',NULL,'SCSEMP20130620251142','',NULL,NULL,1,'Teamleieter','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,'active',NULL,NULL,NULL,NULL,0,'2025-06-13 11:42:39','2025-06-13 11:42:39',NULL,NULL,'available',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_documents_with_recipients`
--

DROP TABLE IF EXISTS `v_documents_with_recipients`;
/*!50001 DROP VIEW IF EXISTS `v_documents_with_recipients`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_documents_with_recipients` AS SELECT 
 1 AS `id`,
 1 AS `tenant_id`,
 1 AS `user_id`,
 1 AS `recipient_type`,
 1 AS `team_id`,
 1 AS `department_id`,
 1 AS `category`,
 1 AS `filename`,
 1 AS `original_name`,
 1 AS `file_path`,
 1 AS `file_size`,
 1 AS `mime_type`,
 1 AS `description`,
 1 AS `tags`,
 1 AS `is_public`,
 1 AS `is_archived`,
 1 AS `uploaded_at`,
 1 AS `archived_at`,
 1 AS `expires_at`,
 1 AS `created_by`,
 1 AS `user_first_name`,
 1 AS `user_last_name`,
 1 AS `user_email`,
 1 AS `team_name`,
 1 AS `team_description`,
 1 AS `department_name`,
 1 AS `department_description`,
 1 AS `uploader_first_name`,
 1 AS `uploader_last_name`,
 1 AS `uploader_email`,
 1 AS `recipient_display_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_tenant_plan_overview`
--

DROP TABLE IF EXISTS `v_tenant_plan_overview`;
/*!50001 DROP VIEW IF EXISTS `v_tenant_plan_overview`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_tenant_plan_overview` AS SELECT 
 1 AS `tenant_id`,
 1 AS `company_name`,
 1 AS `subdomain`,
 1 AS `plan_code`,
 1 AS `plan_name`,
 1 AS `plan_price`,
 1 AS `plan_status`,
 1 AS `plan_started`,
 1 AS `custom_price`,
 1 AS `effective_price`,
 1 AS `addon_cost`,
 1 AS `total_monthly_cost`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `weekly_shift_notes`
--

DROP TABLE IF EXISTS `weekly_shift_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `weekly_shift_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `department_id` int NOT NULL,
  `date` date NOT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_week_tenant_dept` (`tenant_id`,`department_id`,`date`),
  KEY `idx_tenant_date` (`tenant_id`,`date`),
  KEY `created_by` (`created_by`),
  KEY `idx_weekly_notes_dept` (`tenant_id`,`department_id`,`date`),
  KEY `fk_weekly_notes_department` (`department_id`),
  CONSTRAINT `fk_weekly_notes_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `weekly_shift_notes_ibfk_1` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`),
  CONSTRAINT `weekly_shift_notes_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weekly_shift_notes`
--

LOCK TABLES `weekly_shift_notes` WRITE;
/*!40000 ALTER TABLE `weekly_shift_notes` DISABLE KEYS */;
INSERT INTO `weekly_shift_notes` VALUES (9,8,1,'2025-06-09','testnotiz',11,'2025-06-12 21:03:59','2025-06-12 21:03:59');
/*!40000 ALTER TABLE `weekly_shift_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `active_shifts_today`
--

/*!50001 DROP VIEW IF EXISTS `active_shifts_today`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `active_shifts_today` AS select `s`.`id` AS `id`,`s`.`tenant_id` AS `tenant_id`,`s`.`user_id` AS `user_id`,`u`.`first_name` AS `first_name`,`u`.`last_name` AS `last_name`,`s`.`start_time` AS `start_time`,`s`.`end_time` AS `end_time`,`s`.`status` AS `status`,`s`.`type` AS `type`,`st`.`name` AS `template_name`,`d`.`name` AS `department_name` from (((`shifts` `s` join `users` `u` on((`s`.`user_id` = `u`.`id`))) left join `shift_templates` `st` on((`s`.`template_id` = `st`.`id`))) left join `departments` `d` on((`u`.`department_id` = `d`.`id`))) where ((cast(`s`.`date` as date) = curdate()) and (`s`.`status` <> 'cancelled')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `active_surveys`
--

/*!50001 DROP VIEW IF EXISTS `active_surveys`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `active_surveys` AS select `s`.`id` AS `id`,`s`.`tenant_id` AS `tenant_id`,`s`.`title` AS `title`,`s`.`type` AS `type`,`s`.`status` AS `status`,`s`.`is_anonymous` AS `is_anonymous`,`s`.`start_date` AS `start_date`,`s`.`end_date` AS `end_date`,`u`.`first_name` AS `creator_first_name`,`u`.`last_name` AS `creator_last_name`,count(distinct `sq`.`id`) AS `question_count`,count(distinct `sr`.`id`) AS `response_count`,count(distinct (case when (`sr`.`status` = 'completed') then `sr`.`id` end)) AS `completed_count` from (((`surveys` `s` join `users` `u` on((`s`.`created_by` = `u`.`id`))) left join `survey_questions` `sq` on((`s`.`id` = `sq`.`survey_id`))) left join `survey_responses` `sr` on((`s`.`id` = `sr`.`survey_id`))) where ((`s`.`status` = 'active') and ((`s`.`start_date` is null) or (`s`.`start_date` <= now())) and ((`s`.`end_date` is null) or (`s`.`end_date` >= now()))) group by `s`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `current_employee_availability`
--

/*!50001 DROP VIEW IF EXISTS `current_employee_availability`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `current_employee_availability` AS select `u`.`id` AS `employee_id`,`u`.`tenant_id` AS `tenant_id`,`u`.`username` AS `username`,`u`.`first_name` AS `first_name`,`u`.`last_name` AS `last_name`,coalesce((select `ea`.`status` from `employee_availability` `ea` where ((`ea`.`employee_id` = `u`.`id`) and (`ea`.`tenant_id` = `u`.`tenant_id`) and (curdate() between `ea`.`start_date` and `ea`.`end_date`)) order by `ea`.`created_at` desc limit 1),'available') AS `current_status`,(select `ea`.`reason` from `employee_availability` `ea` where ((`ea`.`employee_id` = `u`.`id`) and (`ea`.`tenant_id` = `u`.`tenant_id`) and (curdate() between `ea`.`start_date` and `ea`.`end_date`)) order by `ea`.`created_at` desc limit 1) AS `current_reason`,(select `ea`.`end_date` from `employee_availability` `ea` where ((`ea`.`employee_id` = `u`.`id`) and (`ea`.`tenant_id` = `u`.`tenant_id`) and (curdate() between `ea`.`start_date` and `ea`.`end_date`)) order by `ea`.`created_at` desc limit 1) AS `available_from` from `users` `u` where (`u`.`role` = 'employee') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `document_summary`
--

/*!50001 DROP VIEW IF EXISTS `document_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `document_summary` AS select `d`.`id` AS `id`,`d`.`tenant_id` AS `tenant_id`,`d`.`user_id` AS `user_id`,`d`.`category` AS `category`,`d`.`filename` AS `filename`,`d`.`file_size` AS `file_size`,`d`.`uploaded_at` AS `uploaded_at`,`d`.`is_archived` AS `is_archived`,`u`.`first_name` AS `owner_first_name`,`u`.`last_name` AS `owner_last_name`,`u`.`email` AS `owner_email`,`cu`.`first_name` AS `uploader_first_name`,`cu`.`last_name` AS `uploader_last_name` from ((`documents` `d` join `users` `u` on((`d`.`user_id` = `u`.`id`))) left join `users` `cu` on((`d`.`created_by` = `cu`.`id`))) where (`d`.`is_archived` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `employee_overview`
--

/*!50001 DROP VIEW IF EXISTS `employee_overview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `employee_overview` AS select `u`.`id` AS `id`,`u`.`tenant_id` AS `tenant_id`,`u`.`email` AS `email`,`u`.`first_name` AS `first_name`,`u`.`last_name` AS `last_name`,`u`.`phone` AS `phone`,`u`.`role` AS `role`,`u`.`status` AS `status`,`u`.`created_at` AS `created_at`,`u`.`last_login` AS `last_login`,`d`.`name` AS `department_name`,`t`.`name` AS `team_name`,count(distinct `doc`.`id`) AS `document_count`,count(distinct `msg`.`id`) AS `message_count` from (((((`users` `u` left join `departments` `d` on(((`u`.`department_id` = `d`.`id`) and (`d`.`tenant_id` = `u`.`tenant_id`)))) left join `user_teams` `ut` on(((`u`.`id` = `ut`.`user_id`) and (`ut`.`tenant_id` = `u`.`tenant_id`)))) left join `teams` `t` on(((`ut`.`team_id` = `t`.`id`) and (`t`.`tenant_id` = `u`.`tenant_id`)))) left join `documents` `doc` on(((`u`.`id` = `doc`.`user_id`) and (`doc`.`tenant_id` = `u`.`tenant_id`)))) left join `messages` `msg` on(((`u`.`id` = `msg`.`sender_id`) and (`msg`.`tenant_id` = `u`.`tenant_id`)))) where (`u`.`role` = 'employee') group by `u`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `employees_without_documents`
--

/*!50001 DROP VIEW IF EXISTS `employees_without_documents`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `employees_without_documents` AS select `u`.`id` AS `id`,`u`.`tenant_id` AS `tenant_id`,`u`.`email` AS `email`,`u`.`first_name` AS `first_name`,`u`.`last_name` AS `last_name`,`u`.`created_at` AS `created_at`,`d`.`name` AS `department_name` from ((`users` `u` left join `departments` `d` on((`u`.`department_id` = `d`.`id`))) left join `documents` `doc` on((`u`.`id` = `doc`.`user_id`))) where ((`u`.`role` = 'employee') and (`u`.`status` = 'active') and (`doc`.`id` is null)) group by `u`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `feature_usage_summary`
--

/*!50001 DROP VIEW IF EXISTS `feature_usage_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `feature_usage_summary` AS select `f`.`id` AS `feature_id`,`f`.`code` AS `code`,`f`.`name` AS `name`,`f`.`category` AS `category`,`f`.`base_price` AS `base_price`,count(distinct `tf`.`tenant_id`) AS `tenant_count`,count(distinct `ful`.`id`) AS `usage_count`,sum((case when (`tf`.`is_active` = true) then 1 else 0 end)) AS `active_count`,avg((to_days(now()) - to_days(`tf`.`activated_at`))) AS `avg_days_active` from ((`features` `f` left join `tenant_features` `tf` on((`f`.`id` = `tf`.`feature_id`))) left join `feature_usage_logs` `ful` on((`f`.`id` = `ful`.`feature_id`))) group by `f`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tenant_statistics`
--

/*!50001 DROP VIEW IF EXISTS `tenant_statistics`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tenant_statistics` AS select `t`.`id` AS `tenant_id`,`t`.`company_name` AS `tenant_name`,`t`.`subdomain` AS `subdomain`,`t`.`status` AS `status`,`t`.`current_plan` AS `plan_type`,count(distinct `u`.`id`) AS `total_users`,count(distinct (case when (`u`.`role` = 'admin') then `u`.`id` end)) AS `admin_count`,count(distinct (case when (`u`.`role` = 'employee') then `u`.`id` end)) AS `employee_count`,count(distinct `d`.`id`) AS `department_count`,count(distinct `tm`.`id`) AS `team_count`,count(distinct `tf`.`id`) AS `active_features`,`t`.`created_at` AS `created_at`,`t`.`trial_ends_at` AS `subscription_end_date` from ((((`tenants` `t` left join `users` `u` on(((`t`.`id` = `u`.`tenant_id`) and (`u`.`status` = 'active')))) left join `departments` `d` on((`t`.`id` = `d`.`tenant_id`))) left join `teams` `tm` on((`t`.`id` = `tm`.`tenant_id`))) left join `tenant_features` `tf` on(((`t`.`id` = `tf`.`tenant_id`) and (`tf`.`is_active` = true)))) group by `t`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_documents_with_recipients`
--

/*!50001 DROP VIEW IF EXISTS `v_documents_with_recipients`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_documents_with_recipients` AS select `d`.`id` AS `id`,`d`.`tenant_id` AS `tenant_id`,`d`.`user_id` AS `user_id`,`d`.`recipient_type` AS `recipient_type`,`d`.`team_id` AS `team_id`,`d`.`department_id` AS `department_id`,`d`.`category` AS `category`,`d`.`filename` AS `filename`,`d`.`original_name` AS `original_name`,`d`.`file_path` AS `file_path`,`d`.`file_size` AS `file_size`,`d`.`mime_type` AS `mime_type`,`d`.`description` AS `description`,`d`.`tags` AS `tags`,`d`.`is_public` AS `is_public`,`d`.`is_archived` AS `is_archived`,`d`.`uploaded_at` AS `uploaded_at`,`d`.`archived_at` AS `archived_at`,`d`.`expires_at` AS `expires_at`,`d`.`created_by` AS `created_by`,`u`.`first_name` AS `user_first_name`,`u`.`last_name` AS `user_last_name`,`u`.`email` AS `user_email`,`t`.`name` AS `team_name`,`t`.`description` AS `team_description`,`dept`.`name` AS `department_name`,`dept`.`description` AS `department_description`,`uploader`.`first_name` AS `uploader_first_name`,`uploader`.`last_name` AS `uploader_last_name`,`uploader`.`email` AS `uploader_email`,(case when (`d`.`recipient_type` = 'user') then concat(`u`.`first_name`,' ',`u`.`last_name`) when (`d`.`recipient_type` = 'team') then concat('Team: ',`t`.`name`) when (`d`.`recipient_type` = 'department') then concat('Abteilung: ',`dept`.`name`) when (`d`.`recipient_type` = 'company') then 'Gesamte Firma' else 'Unbekannt' end) AS `recipient_display_name` from ((((`documents` `d` left join `users` `u` on(((`d`.`user_id` = `u`.`id`) and (`d`.`recipient_type` = 'user')))) left join `teams` `t` on(((`d`.`team_id` = `t`.`id`) and (`d`.`recipient_type` = 'team')))) left join `departments` `dept` on(((`d`.`department_id` = `dept`.`id`) and (`d`.`recipient_type` = 'department')))) left join `users` `uploader` on((`d`.`created_by` = `uploader`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_tenant_plan_overview`
--

/*!50001 DROP VIEW IF EXISTS `v_tenant_plan_overview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tenant_plan_overview` AS select `t`.`id` AS `tenant_id`,`t`.`company_name` AS `company_name`,`t`.`subdomain` AS `subdomain`,`p`.`code` AS `plan_code`,`p`.`name` AS `plan_name`,`p`.`base_price` AS `plan_price`,`tp`.`status` AS `plan_status`,`tp`.`started_at` AS `plan_started`,`tp`.`custom_price` AS `custom_price`,coalesce(`tp`.`custom_price`,`p`.`base_price`) AS `effective_price`,(select sum(`tenant_addons`.`total_price`) from `tenant_addons` where ((`tenant_addons`.`tenant_id` = `t`.`id`) and (`tenant_addons`.`status` = 'active'))) AS `addon_cost`,(coalesce(`tp`.`custom_price`,`p`.`base_price`) + coalesce((select sum(`tenant_addons`.`total_price`) from `tenant_addons` where ((`tenant_addons`.`tenant_id` = `t`.`id`) and (`tenant_addons`.`status` = 'active'))),0)) AS `total_monthly_cost` from ((`tenants` `t` left join `tenant_plans` `tp` on(((`t`.`id` = `tp`.`tenant_id`) and (`tp`.`status` = 'active')))) left join `plans` `p` on((`tp`.`plan_id` = `p`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-17 13:59:53
